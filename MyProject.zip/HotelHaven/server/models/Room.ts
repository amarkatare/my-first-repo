import mongoose, { Document, Schema } from 'mongoose';
import { IAmenity } from './Amenity';
import { ILocation } from './Location';

// Room interface
export interface IRoom extends Document {
  name: string;
  description: string;
  price: number;
  image: string;
  type: 'standard' | 'deluxe' | 'suite' | 'luxury';
  features: string[];
  capacity: number;
  location: mongoose.Types.ObjectId | ILocation;
  amenities: mongoose.Types.ObjectId[] | IAmenity[];
  isFeatured: boolean;
  isNewProperty: boolean;
  rating: number;
  details?: string;
  createdAt: Date;
  updatedAt: Date;
}

// Room schema
const roomSchema = new Schema<IRoom>(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      required: true,
      trim: true,
    },
    price: {
      type: Number,
      required: true,
      min: 0,
    },
    image: {
      type: String,
      required: true,
    },
    type: {
      type: String,
      enum: ['standard', 'deluxe', 'suite', 'luxury'],
      required: true,
    },
    features: [{
      type: String,
      trim: true,
    }],
    capacity: {
      type: Number,
      required: true,
      min: 1,
    },
    location: {
      type: Schema.Types.ObjectId,
      ref: 'Location',
      required: true,
    },
    amenities: [{
      type: Schema.Types.ObjectId,
      ref: 'Amenity',
    }],
    isFeatured: {
      type: Boolean,
      default: false,
    },
    isNewProperty: {
      type: Boolean,
      default: false,
    },
    rating: {
      type: Number,
      default: 0,
      min: 0,
      max: 5,
    },
    details: {
      type: String,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

// Create Room model
export const Room = mongoose.model<IRoom>('Room', roomSchema);