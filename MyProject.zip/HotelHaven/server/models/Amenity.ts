import mongoose, { Document, Schema } from 'mongoose';

// Amenity interface
export interface IAmenity extends Document {
  name: string;
  description?: string;
  icon?: string;
  createdAt: Date;
  updatedAt: Date;
}

// Amenity schema
const amenitySchema = new Schema<IAmenity>(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      unique: true,
    },
    description: {
      type: String,
      trim: true,
    },
    icon: {
      type: String,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

// Create Amenity model
export const Amenity = mongoose.model<IAmenity>('Amenity', amenitySchema);