import mongoose, { Document, Schema } from 'mongoose';
import { IUser } from './User';

// Testimonial interface
export interface ITestimonial extends Document {
  user: mongoose.Types.ObjectId | IUser;
  text: string;
  rating: number;
  createdAt: Date;
  updatedAt: Date;
}

// Testimonial schema
const testimonialSchema = new Schema<ITestimonial>(
  {
    user: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    text: {
      type: String,
      required: true,
      trim: true,
      minlength: 10,
      maxlength: 500,
    },
    rating: {
      type: Number,
      required: true,
      min: 1,
      max: 5,
    },
  },
  {
    timestamps: true,
  }
);

// Create Testimonial model
export const Testimonial = mongoose.model<ITestimonial>('Testimonial', testimonialSchema);