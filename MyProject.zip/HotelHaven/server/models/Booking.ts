import mongoose, { Document, Schema } from 'mongoose';
import { IRoom } from './Room';
import { IUser } from './User';

// Booking status type
export type BookingStatus = 'pending' | 'confirmed' | 'cancelled' | 'completed';

// Booking interface
export interface IBooking extends Document {
  room: mongoose.Types.ObjectId | IRoom;
  user: mongoose.Types.ObjectId | IUser;
  checkIn: Date;
  checkOut: Date;
  guests: number;
  totalCost: number;
  status: BookingStatus;
  createdAt: Date;
  updatedAt: Date;
}

// Booking schema
const bookingSchema = new Schema<IBooking>(
  {
    room: {
      type: Schema.Types.ObjectId,
      ref: 'Room',
      required: true,
    },
    user: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    checkIn: {
      type: Date,
      required: true,
    },
    checkOut: {
      type: Date,
      required: true,
    },
    guests: {
      type: Number,
      required: true,
      min: 1,
    },
    totalCost: {
      type: Number,
      required: true,
      min: 0,
    },
    status: {
      type: String,
      enum: ['pending', 'confirmed', 'cancelled', 'completed'],
      default: 'pending',
    },
  },
  {
    timestamps: true,
  }
);

// Validate that check-out date is after check-in date
bookingSchema.pre('validate', function (next) {
  if (this.checkOut <= this.checkIn) {
    this.invalidate('checkOut', 'Check-out date must be after check-in date');
  }
  next();
});

// Create Booking model
export const Booking = mongoose.model<IBooking>('Booking', bookingSchema);