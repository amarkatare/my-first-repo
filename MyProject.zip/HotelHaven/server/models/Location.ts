import mongoose, { Document, Schema } from 'mongoose';

// Location interface
export interface ILocation extends Document {
  name: string;
  description?: string;
  createdAt: Date;
  updatedAt: Date;
}

// Location schema
const locationSchema = new Schema<ILocation>(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      unique: true,
    },
    description: {
      type: String,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

// Create Location model
export const Location = mongoose.model<ILocation>('Location', locationSchema);