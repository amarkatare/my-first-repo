import mongoose, { Document, Schema } from 'mongoose';

// Subscriber interface
export interface ISubscriber extends Document {
  email: string;
  createdAt: Date;
  updatedAt: Date;
}

// Subscriber schema
const subscriberSchema = new Schema<ISubscriber>(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
      // Simple email validation
      match: [/^\S+@\S+\.\S+$/, 'Please use a valid email address'],
    },
  },
  {
    timestamps: true,
  }
);

// Create Subscriber model
export const Subscriber = mongoose.model<ISubscriber>('Subscriber', subscriberSchema);