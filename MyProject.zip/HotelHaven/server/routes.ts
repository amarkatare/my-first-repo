import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage-mongo";
import { setupAuth } from "./auth";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes and middleware
  setupAuth(app);

  const httpServer = createServer(app);

  // API routes
  const apiPrefix = "/api";

  // Locations API
  app.get(`${apiPrefix}/locations`, async (req, res) => {
    try {
      const locations = await storage.getAllLocations();
      res.json(locations);
    } catch (error) {
      console.error("Error getting locations:", error);
      res.status(500).json({ message: "Failed to get locations" });
    }
  });

  // Amenities API
  app.get(`${apiPrefix}/amenities`, async (req, res) => {
    try {
      const amenities = await storage.getAllAmenities();
      res.json(amenities);
    } catch (error) {
      console.error("Error getting amenities:", error);
      res.status(500).json({ message: "Failed to get amenities" });
    }
  });

  // Rooms API
  app.get(`${apiPrefix}/rooms`, async (req, res) => {
    try {
      const { 
        locationId, 
        checkIn, 
        checkOut, 
        guests, 
        maxPrice, 
        roomType, 
        amenities: amenitiesParam,
        sortBy 
      } = req.query;

      let filters: any = {};
      
      if (locationId) {
        filters.locationId = locationId.toString();
      }
      
      if (guests) {
        filters.capacity = { min: Number(guests) };
      }
      
      if (maxPrice) {
        filters.maxPrice = Number(maxPrice);
      }
      
      if (roomType && roomType !== "all_types") {
        filters.type = roomType as string;
      }
      
      // Handle date filtering for availability
      if (checkIn && checkOut) {
        filters.checkIn = checkIn as string;
        filters.checkOut = checkOut as string;
      }
      
      // Handle amenities filtering
      let amenitiesFilter: string[] | undefined;
      if (amenitiesParam) {
        if (Array.isArray(amenitiesParam)) {
          amenitiesFilter = amenitiesParam as string[];
        } else {
          amenitiesFilter = [amenitiesParam as string];
        }
      }
      
      // Determine sort order
      let sortOptions = { field: "price", direction: "asc" };
      if (sortBy) {
        const [field, direction] = (sortBy as string).split("-");
        if (field === "price" || field === "rating") {
          sortOptions = { field, direction: direction || "asc" };
        } else if (field === "newest") {
          sortOptions = { field: "createdAt", direction: "desc" };
        }
      }
      
      const availableRooms = await storage.getRoomsWithFilters(
        filters, 
        amenitiesFilter, 
        sortOptions
      );
      
      res.json(availableRooms);
    } catch (error) {
      console.error("Error getting rooms:", error);
      res.status(500).json({ message: "Failed to get rooms" });
    }
  });

  app.get(`${apiPrefix}/rooms/max-price`, async (req, res) => {
    try {
      const maxPrice = await storage.getMaxRoomPrice();
      res.json({ maxPrice });
    } catch (error) {
      console.error("Error getting max room price:", error);
      res.status(500).json({ message: "Failed to get max room price" });
    }
  });

  app.get(`${apiPrefix}/rooms/featured`, async (req, res) => {
    try {
      const featuredRooms = await storage.getFeaturedRooms();
      res.json(featuredRooms);
    } catch (error) {
      console.error("Error getting featured rooms:", error);
      res.status(500).json({ message: "Failed to get featured rooms" });
    }
  });

  app.get(`${apiPrefix}/rooms/:id`, async (req, res) => {
    try {
      const { id } = req.params;
      const room = await storage.getRoomById(id);
      
      if (!room) {
        return res.status(404).json({ message: "Room not found" });
      }
      
      res.json(room);
    } catch (error) {
      console.error("Error getting room:", error);
      res.status(500).json({ message: "Failed to get room" });
    }
  });

  // Rooms CRUD for admin
  app.get(`${apiPrefix}/rooms/all`, async (req, res) => {
    try {
      // This should be protected with admin auth middleware
      if (!req.user || req.user.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const allRooms = await storage.getAllRooms();
      res.json(allRooms);
    } catch (error) {
      console.error("Error getting all rooms:", error);
      res.status(500).json({ message: "Failed to get all rooms" });
    }
  });

  app.post(`${apiPrefix}/rooms`, async (req, res) => {
    try {
      // Admin check
      if (!req.user || req.user.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      // MongoDB version doesn't need schema validation through Zod
      const newRoom = await storage.insertRoom(req.body);
      res.status(201).json(newRoom);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating room:", error);
      res.status(500).json({ message: "Failed to create room" });
    }
  });

  app.put(`${apiPrefix}/rooms/:id`, async (req, res) => {
    try {
      // Admin check
      if (!req.user || req.user.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const { id } = req.params;
      // MongoDB version doesn't need schema validation through Zod
      const updatedRoom = await storage.updateRoom(id, req.body);
      
      if (!updatedRoom) {
        return res.status(404).json({ message: "Room not found" });
      }
      
      res.json(updatedRoom);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error updating room:", error);
      res.status(500).json({ message: "Failed to update room" });
    }
  });

  app.delete(`${apiPrefix}/rooms/:id`, async (req, res) => {
    try {
      // Admin check
      if (!req.user || req.user.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const { id } = req.params;
      const result = await storage.deleteRoom(id);
      
      if (!result) {
        return res.status(404).json({ message: "Room not found" });
      }
      
      res.json({ message: "Room deleted successfully" });
    } catch (error) {
      console.error("Error deleting room:", error);
      res.status(500).json({ message: "Failed to delete room" });
    }
  });

  // Testimonials API
  app.get(`${apiPrefix}/testimonials`, async (req, res) => {
    try {
      const testimonials = await storage.getActiveTestimonials();
      res.json(testimonials);
    } catch (error) {
      console.error("Error getting testimonials:", error);
      res.status(500).json({ message: "Failed to get testimonials" });
    }
  });

  // Bookings API
  app.post(`${apiPrefix}/bookings`, async (req, res) => {
    try {
      // Authentication check
      if (!req.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const bookingData = {
        ...req.body,
        user: req.user.id,
      };
      
      // MongoDB version doesn't need schema validation through Zod
      const newBooking = await storage.createBooking(bookingData);
      res.status(201).json(newBooking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating booking:", error);
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  app.get(`${apiPrefix}/user/bookings`, async (req, res) => {
    try {
      // Authentication check
      if (!req.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      // In MongoDB, we use the actual ID string
      const userBookings = await storage.getUserBookings(req.user.id.toString());
      res.json(userBookings);
    } catch (error) {
      console.error("Error getting user bookings:", error);
      res.status(500).json({ message: "Failed to get user bookings" });
    }
  });

  // Admin bookings management
  app.get(`${apiPrefix}/bookings/all`, async (req, res) => {
    try {
      // Admin check
      if (!req.user || req.user.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const allBookings = await storage.getAllBookings();
      res.json(allBookings);
    } catch (error) {
      console.error("Error getting all bookings:", error);
      res.status(500).json({ message: "Failed to get all bookings" });
    }
  });

  app.patch(`${apiPrefix}/bookings/:id/status`, async (req, res) => {
    try {
      // Admin check
      if (!req.user || req.user.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const { id } = req.params;
      const { status } = req.body;
      
      if (!["pending", "confirmed", "cancelled", "completed"].includes(status)) {
        return res.status(400).json({ message: "Invalid status value" });
      }
      
      const updatedBooking = await storage.updateBookingStatus(id, status);
      
      if (!updatedBooking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.json(updatedBooking);
    } catch (error) {
      console.error("Error updating booking status:", error);
      res.status(500).json({ message: "Failed to update booking status" });
    }
  });

  // Newsletter subscription
  app.post(`${apiPrefix}/newsletter`, async (req, res) => {
    try {
      // MongoDB version doesn't need schema validation through Zod
      await storage.addSubscriber(req.body);
      res.status(201).json({ message: "Successfully subscribed to newsletter" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error subscribing to newsletter:", error);
      res.status(500).json({ message: "Failed to subscribe to newsletter" });
    }
  });

  // Admin dashboard summary
  app.get(`${apiPrefix}/admin/dashboard-summary`, async (req, res) => {
    try {
      // Admin check
      if (!req.user || req.user.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const summary = await storage.getDashboardSummary();
      res.json(summary);
    } catch (error) {
      console.error("Error getting dashboard summary:", error);
      res.status(500).json({ message: "Failed to get dashboard summary" });
    }
  });

  return httpServer;
}
