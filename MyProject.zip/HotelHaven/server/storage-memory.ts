import { log } from './vite';
import { hash } from './utils/hash';
import { IUser, IRoom, IBooking, ILocation, IAmenity, ITestimonial, ISubscriber } from './models';

// Interface for room filters
interface RoomFilters {
  locationId?: string;
  capacity?: { min: number };
  maxPrice?: number;
  type?: string;
  checkIn?: string;
  checkOut?: string;
}

// Interface for sort options
interface SortOptions {
  field: string;
  direction: string;
}

// In-memory storage
const inMemoryDB: {
  users: Array<any>;
  rooms: Array<any>;
  bookings: Array<any>;
  locations: Array<any>;
  amenities: Array<any>;
  testimonials: Array<any>;
  subscribers: Array<any>;
} = {
  users: [],
  rooms: [],
  bookings: [],
  locations: [],
  amenities: [],
  testimonials: [],
  subscribers: []
};

// Initialize with some seed data
async function seedInMemoryDB() {
  // Create admin user if not exists
  if (inMemoryDB.users.length === 0) {
    const hashedPassword = await hash('adminpassword');
    inMemoryDB.users.push({
      _id: '1',
      username: 'admin',
      password: hashedPassword,
      fullName: 'Admin User',
      email: 'admin@example.com',
      role: 'admin',
      createdAt: new Date(),
      updatedAt: new Date()
    });
    
    inMemoryDB.users.push({
      _id: '2',
      username: 'user',
      password: await hash('userpassword'),
      fullName: 'Regular User',
      email: 'user@example.com',
      role: 'user',
      createdAt: new Date(),
      updatedAt: new Date()
    });

    log('Created seed users in memory', 'database');
  }

  // Create seed locations
  if (inMemoryDB.locations.length === 0) {
    inMemoryDB.locations.push({
      _id: '1',
      name: 'Ashta, India',
      description: 'Beautiful city in India',
      createdAt: new Date(),
      updatedAt: new Date()
    });
    
    inMemoryDB.locations.push({
      _id: '2',
      name: 'Mumbai, India',
      description: 'Financial capital of India',
      createdAt: new Date(),
      updatedAt: new Date()
    });

    log('Created seed locations in memory', 'database');
  }

  // Create seed amenities
  if (inMemoryDB.amenities.length === 0) {
    inMemoryDB.amenities.push({
      _id: '1',
      name: 'Free WiFi',
      description: 'High-speed wireless internet',
      icon: 'wifi',
      createdAt: new Date(),
      updatedAt: new Date()
    });
    
    inMemoryDB.amenities.push({
      _id: '2',
      name: 'Swimming Pool',
      description: 'Outdoor swimming pool',
      icon: 'pool',
      createdAt: new Date(),
      updatedAt: new Date()
    });
    
    inMemoryDB.amenities.push({
      _id: '3',
      name: 'Gym',
      description: 'Fully equipped fitness center',
      icon: 'fitness',
      createdAt: new Date(),
      updatedAt: new Date()
    });

    log('Created seed amenities in memory', 'database');
  }

  // Create seed rooms
  if (inMemoryDB.rooms.length === 0) {
    inMemoryDB.rooms.push({
      _id: '1',
      name: 'Deluxe Room',
      description: 'Spacious room with all amenities',
      price: 150,
      image: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304',
      type: 'deluxe',
      features: ['King size bed', 'City view', 'Mini bar'],
      capacity: 2,
      location: '1',
      amenities: ['1', '2'],
      isFeatured: true,
      isNewProperty: true,
      rating: 4.5,
      details: 'Luxurious room with all modern amenities for a comfortable stay',
      createdAt: new Date(),
      updatedAt: new Date()
    });
    
    inMemoryDB.rooms.push({
      _id: '2',
      name: 'Suite',
      description: 'Luxury suite with separate living area',
      price: 300,
      image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427',
      type: 'suite',
      features: ['King size bed', 'Ocean view', 'Jacuzzi', 'Living area'],
      capacity: 4,
      location: '2',
      amenities: ['1', '2', '3'],
      isFeatured: true,
      isNewProperty: false,
      rating: 4.8,
      details: 'Our most luxurious accommodation with separate living and dining areas',
      createdAt: new Date(),
      updatedAt: new Date()
    });

    log('Created seed rooms in memory', 'database');
  }

  // Create seed testimonials
  if (inMemoryDB.testimonials.length === 0) {
    inMemoryDB.testimonials.push({
      _id: '1',
      user: '2',
      text: 'Amazing experience! The room was clean and comfortable.',
      rating: 5,
      createdAt: new Date(),
      updatedAt: new Date()
    });

    log('Created seed testimonials in memory', 'database');
  }
}

// Initialize the in-memory database
seedInMemoryDB();

// In-memory storage service
export const memoryStorage = {
  // User methods
  getUserByUsername: async (username: string): Promise<IUser | null> => {
    return inMemoryDB.users.find(user => user.username === username) || null;
  },

  getUserById: async (id: string): Promise<IUser | null> => {
    return inMemoryDB.users.find(user => user._id === id) || null;
  },

  createUser: async (userData: any): Promise<any> => {
    const id = (inMemoryDB.users.length + 1).toString();
    const hashedPassword = await hash(userData.password);
    
    const newUser = {
      _id: id,
      ...userData,
      password: hashedPassword,
      role: userData.role || 'user',
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    inMemoryDB.users.push(newUser);
    return newUser;
  },

  // Location methods
  getAllLocations: async (): Promise<any[]> => {
    return inMemoryDB.locations;
  },

  getLocationById: async (id: string): Promise<any | null> => {
    return inMemoryDB.locations.find(location => location._id === id) || null;
  },

  insertLocation: async (locationData: any): Promise<any> => {
    const id = (inMemoryDB.locations.length + 1).toString();
    
    const newLocation = {
      _id: id,
      ...locationData,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    inMemoryDB.locations.push(newLocation);
    return newLocation;
  },

  // Amenity methods
  getAllAmenities: async (): Promise<any[]> => {
    return inMemoryDB.amenities;
  },

  getAmenityById: async (id: string): Promise<any | null> => {
    return inMemoryDB.amenities.find(amenity => amenity._id === id) || null;
  },

  insertAmenity: async (amenityData: any): Promise<any> => {
    const id = (inMemoryDB.amenities.length + 1).toString();
    
    const newAmenity = {
      _id: id,
      ...amenityData,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    inMemoryDB.amenities.push(newAmenity);
    return newAmenity;
  },

  // Room methods
  getAllRooms: async (): Promise<any[]> => {
    return inMemoryDB.rooms.map(room => {
      // Populate location
      const location = inMemoryDB.locations.find(loc => loc._id === room.location);
      
      // Populate amenities
      const amenities = room.amenities.map((amenityId: string) => 
        inMemoryDB.amenities.find(amenity => amenity._id === amenityId)
      ).filter(Boolean);
      
      return { ...room, location, amenities };
    });
  },

  getRoomById: async (id: string): Promise<any | null> => {
    const room = inMemoryDB.rooms.find(room => room._id === id);
    if (!room) return null;
    
    // Populate location
    const location = inMemoryDB.locations.find(loc => loc._id === room.location);
    
    // Populate amenities
    const amenities = room.amenities.map((amenityId: string) => 
      inMemoryDB.amenities.find(amenity => amenity._id === amenityId)
    ).filter(Boolean);
    
    return { ...room, location, amenities };
  },

  getFeaturedRooms: async (): Promise<any[]> => {
    return inMemoryDB.rooms
      .filter(room => room.isFeatured)
      .map(room => {
        // Populate location
        const location = inMemoryDB.locations.find(loc => loc._id === room.location);
        
        // Populate amenities
        const amenities = room.amenities.map((amenityId: string) => 
          inMemoryDB.amenities.find(amenity => amenity._id === amenityId)
        ).filter(Boolean);
        
        return { ...room, location, amenities };
      });
  },

  getMaxRoomPrice: async (): Promise<number> => {
    if (inMemoryDB.rooms.length === 0) return 0;
    return Math.max(...inMemoryDB.rooms.map(room => room.price));
  },

  getRoomsWithFilters: async (
    filters: RoomFilters,
    amenitiesFilter?: string[],
    sortOptions: SortOptions = { field: "price", direction: "asc" }
  ): Promise<any[]> => {
    let filteredRooms = [...inMemoryDB.rooms];
    
    // Apply filters
    if (filters.locationId) {
      filteredRooms = filteredRooms.filter(room => room.location === filters.locationId);
    }
    
    if (filters.capacity && filters.capacity.min) {
      filteredRooms = filteredRooms.filter(room => room.capacity >= filters.capacity.min);
    }
    
    if (filters.maxPrice) {
      filteredRooms = filteredRooms.filter(room => room.price <= filters.maxPrice);
    }
    
    if (filters.type && filters.type !== 'all_types') {
      filteredRooms = filteredRooms.filter(room => room.type === filters.type);
    }
    
    // Booking date availability filter
    if (filters.checkIn && filters.checkOut) {
      const checkIn = new Date(filters.checkIn);
      const checkOut = new Date(filters.checkOut);
      
      // Get rooms that are not booked during the selected period
      const bookedRoomIds = inMemoryDB.bookings
        .filter(booking => {
          const bookingCheckIn = new Date(booking.checkIn);
          const bookingCheckOut = new Date(booking.checkOut);
          
          return (
            (bookingCheckIn < checkOut && bookingCheckOut > checkIn) ||
            (bookingCheckIn >= checkIn && bookingCheckIn < checkOut) ||
            (bookingCheckOut > checkIn && bookingCheckOut <= checkOut)
          ) && booking.status !== 'cancelled';
        })
        .map(booking => booking.room);
      
      filteredRooms = filteredRooms.filter(room => !bookedRoomIds.includes(room._id));
    }
    
    // Amenities filter
    if (amenitiesFilter && amenitiesFilter.length > 0) {
      filteredRooms = filteredRooms.filter(room => {
        return amenitiesFilter.every(amenityId => room.amenities.includes(amenityId));
      });
    }
    
    // Populate location and amenities
    filteredRooms = filteredRooms.map(room => {
      const location = inMemoryDB.locations.find(loc => loc._id === room.location);
      const amenities = room.amenities.map((amenityId: string) => 
        inMemoryDB.amenities.find(amenity => amenity._id === amenityId)
      ).filter(Boolean);
      
      return { ...room, location, amenities };
    });
    
    // Sorting
    filteredRooms.sort((a, b) => {
      const sortField = sortOptions.field;
      const sortDirection = sortOptions.direction === 'asc' ? 1 : -1;
      
      if (a[sortField] < b[sortField]) return -1 * sortDirection;
      if (a[sortField] > b[sortField]) return 1 * sortDirection;
      return 0;
    });
    
    return filteredRooms;
  },

  insertRoom: async (roomData: any): Promise<any> => {
    const id = (inMemoryDB.rooms.length + 1).toString();
    
    const newRoom = {
      _id: id,
      ...roomData,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    inMemoryDB.rooms.push(newRoom);
    return newRoom;
  },

  updateRoom: async (id: string, roomData: any): Promise<any | null> => {
    const roomIndex = inMemoryDB.rooms.findIndex(room => room._id === id);
    if (roomIndex === -1) return null;
    
    const updatedRoom = {
      ...inMemoryDB.rooms[roomIndex],
      ...roomData,
      updatedAt: new Date()
    };
    
    inMemoryDB.rooms[roomIndex] = updatedRoom;
    
    // Populate location and amenities for response
    const location = inMemoryDB.locations.find(loc => loc._id === updatedRoom.location);
    const amenities = updatedRoom.amenities.map((amenityId: string) => 
      inMemoryDB.amenities.find(amenity => amenity._id === amenityId)
    ).filter(Boolean);
    
    return { ...updatedRoom, location, amenities };
  },

  deleteRoom: async (id: string): Promise<boolean> => {
    const initialLength = inMemoryDB.rooms.length;
    inMemoryDB.rooms = inMemoryDB.rooms.filter(room => room._id !== id);
    return inMemoryDB.rooms.length < initialLength;
  },

  // Booking methods
  createBooking: async (bookingData: any): Promise<any> => {
    const id = (inMemoryDB.bookings.length + 1).toString();
    
    const newBooking = {
      _id: id,
      ...bookingData,
      status: bookingData.status || 'pending',
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    inMemoryDB.bookings.push(newBooking);
    return newBooking;
  },

  getBookingById: async (id: string): Promise<any | null> => {
    const booking = inMemoryDB.bookings.find(booking => booking._id === id);
    if (!booking) return null;
    
    // Populate user
    const user = inMemoryDB.users.find(user => user._id === booking.user);
    
    // Populate room and its location
    const room = inMemoryDB.rooms.find(room => room._id === booking.room);
    const location = room ? inMemoryDB.locations.find(loc => loc._id === room.location) : null;
    
    return { 
      ...booking, 
      user,
      room: room ? { ...room, location } : null
    };
  },

  getUserBookings: async (userId: string): Promise<any[]> => {
    return inMemoryDB.bookings
      .filter(booking => booking.user === userId)
      .map(booking => {
        // Populate room and its location
        const room = inMemoryDB.rooms.find(room => room._id === booking.room);
        const location = room ? inMemoryDB.locations.find(loc => loc._id === room.location) : null;
        
        return { 
          ...booking,
          room: room ? { ...room, location } : null
        };
      })
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  getAllBookings: async (): Promise<any[]> => {
    return inMemoryDB.bookings
      .map(booking => {
        // Populate user
        const user = inMemoryDB.users.find(user => user._id === booking.user);
        
        // Populate room and its location
        const room = inMemoryDB.rooms.find(room => room._id === booking.room);
        const location = room ? inMemoryDB.locations.find(loc => loc._id === room.location) : null;
        
        return { 
          ...booking, 
          user,
          room: room ? { ...room, location } : null
        };
      })
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  updateBookingStatus: async (id: string, status: string): Promise<any | null> => {
    const bookingIndex = inMemoryDB.bookings.findIndex(booking => booking._id === id);
    if (bookingIndex === -1) return null;
    
    const updatedBooking = {
      ...inMemoryDB.bookings[bookingIndex],
      status,
      updatedAt: new Date()
    };
    
    inMemoryDB.bookings[bookingIndex] = updatedBooking;
    
    // Populate user
    const user = inMemoryDB.users.find(user => user._id === updatedBooking.user);
    
    // Populate room and its location
    const room = inMemoryDB.rooms.find(room => room._id === updatedBooking.room);
    const location = room ? inMemoryDB.locations.find(loc => loc._id === room.location) : null;
    
    return { 
      ...updatedBooking, 
      user,
      room: room ? { ...room, location } : null
    };
  },

  // Testimonial methods
  getActiveTestimonials: async (): Promise<any[]> => {
    return inMemoryDB.testimonials
      .map(testimonial => {
        // Populate user (only fullName)
        const user = inMemoryDB.users.find(user => user._id === testimonial.user);
        
        return { 
          ...testimonial, 
          user: user ? { fullName: user.fullName } : null
        };
      })
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  insertTestimonial: async (testimonialData: any): Promise<any> => {
    const id = (inMemoryDB.testimonials.length + 1).toString();
    
    const newTestimonial = {
      _id: id,
      ...testimonialData,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    inMemoryDB.testimonials.push(newTestimonial);
    return newTestimonial;
  },

  // Subscriber methods
  addSubscriber: async (subscriberData: any): Promise<any> => {
    const id = (inMemoryDB.subscribers.length + 1).toString();
    
    const newSubscriber = {
      _id: id,
      ...subscriberData,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    inMemoryDB.subscribers.push(newSubscriber);
    return newSubscriber;
  },

  // Dashboard summary for admin
  getDashboardSummary: async (): Promise<any> => {
    const totalRooms = inMemoryDB.rooms.length;
    const totalBookings = inMemoryDB.bookings.length;
    const pendingBookings = inMemoryDB.bookings.filter(booking => booking.status === 'pending').length;
    
    // Calculate revenue
    const confirmedBookings = inMemoryDB.bookings.filter(booking => 
      ['confirmed', 'completed'].includes(booking.status)
    );
    const revenue = confirmedBookings.reduce((sum, booking) => sum + booking.totalCost, 0);
    
    // Recent bookings
    const recentBookings = inMemoryDB.bookings
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5)
      .map(booking => {
        const user = inMemoryDB.users.find(user => user._id === booking.user);
        const room = inMemoryDB.rooms.find(room => room._id === booking.room);
        
        return {
          id: booking._id,
          roomName: room ? room.name : 'Unknown Room',
          userName: user ? user.fullName : 'Unknown User',
          checkIn: booking.checkIn,
          totalCost: booking.totalCost
        };
      });
    
    // Popular rooms
    const roomBookingCounts: Record<string, number> = {};
    inMemoryDB.bookings.forEach(booking => {
      const roomId = booking.room;
      roomBookingCounts[roomId] = (roomBookingCounts[roomId] || 0) + 1;
    });
    
    const popularRoomIds = Object.entries(roomBookingCounts)
      .sort(([_, countA], [__, countB]) => countB - countA)
      .slice(0, 5)
      .map(([roomId, _]) => roomId);
    
    const popularRooms = popularRoomIds
      .map(roomId => {
        const room = inMemoryDB.rooms.find(room => room._id === roomId);
        if (!room) return null;
        
        return {
          id: room._id,
          name: room.name,
          bookingsCount: roomBookingCounts[roomId]
        };
      })
      .filter(Boolean);
    
    return {
      totalRooms,
      totalBookings,
      pendingBookings,
      revenue,
      recentBookings,
      popularRooms
    };
  }
};