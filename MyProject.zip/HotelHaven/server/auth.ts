import type { Express, Request, Response, NextFunction } from "express";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import session from "express-session";
import { z } from "zod";
import { storage } from "./storage-mongo";
import bcrypt from "bcrypt";
import { randomBytes } from "crypto";
import type { IUser } from './models';

// Session types
declare global {
  namespace Express {
    interface User {
      id: string;
      username: string;
      fullName: string;
      email: string;
      phone?: string;
      role: string;
    }
  }
}

// Authentication helpers
export const hash = async (password: string): Promise<string> => {
  const saltRounds = 10;
  return await bcrypt.hash(password, saltRounds);
};

export const compare = async (password: string, hashedPassword: string): Promise<boolean> => {
  return await bcrypt.compare(password, hashedPassword);
};

export const setupAuth = (app: Express) => {
  // Configure session
  const secret = process.env.SESSION_SECRET || randomBytes(32).toString("hex");
  
  // Simple in-memory session store for MongoDB version
  app.use(
    session({
      secret,
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000, // 1 day
      },
    })
  );

  // Initialize Passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure Passport local strategy
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        
        if (!user) {
          return done(null, false, { message: "Incorrect username" });
        }
        
        const isValidPassword = await compare(password, user.password);
        
        if (!isValidPassword) {
          return done(null, false, { message: "Incorrect password" });
        }
        
        // Cast to IUser to access _id property (which exists on Mongoose documents)
        const userDoc = user as IUser & { _id: any };
        return done(null, {
          id: userDoc._id ? userDoc._id.toString() : '',
          username: userDoc.username,
          fullName: userDoc.fullName,
          email: userDoc.email,
          phone: userDoc.phone,
          role: userDoc.role,
        });
      } catch (error) {
        return done(error);
      }
    })
  );

  // Serialize and deserialize user
  passport.serializeUser((user: Express.User, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await storage.getUserById(id);
      
      if (!user) {
        return done(null, false);
      }
      
      // Cast to IUser to access _id property (which exists on Mongoose documents)
      const userDoc = user as IUser & { _id: any };
      done(null, {
        id: userDoc._id ? userDoc._id.toString() : '',
        username: userDoc.username,
        fullName: userDoc.fullName,
        email: userDoc.email,
        phone: userDoc.phone,
        role: userDoc.role,
      });
    } catch (error) {
      done(error);
    }
  });

  // Authentication routes
  const apiPrefix = "/api";

  // Register route
  app.post(`${apiPrefix}/auth/register`, async (req, res) => {
    try {
      const registerSchema = z.object({
        username: z.string().min(3, "Username must be at least 3 characters"),
        password: z.string().min(6, "Password must be at least 6 characters"),
        fullName: z.string().min(3, "Full name must be at least 3 characters"),
        email: z.string().email("Please enter a valid email address"),
        phone: z.string().optional(),
      });
      
      const validatedData = registerSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      
      if (existingUser) {
        return res.status(400).json({ message: "Username already taken" });
      }
      
      const newUser = await storage.createUser(validatedData);
      res.status(201).json({ message: "User registered successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Registration error:", error);
      res.status(500).json({ message: "Error registering user" });
    }
  });

  // Login route
  app.post(`${apiPrefix}/auth/login`, (req, res, next) => {
    passport.authenticate("local", (err: any, user: Express.User | false, info: { message: string }) => {
      if (err) {
        return next(err);
      }
      
      if (!user) {
        return res.status(401).json({ message: info?.message || "Authentication failed" });
      }
      
      req.login(user, (err) => {
        if (err) {
          return next(err);
        }
        
        return res.json(user);
      });
    })(req, res, next);
  });

  // Logout route
  app.post(`${apiPrefix}/auth/logout`, (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Error logging out" });
      }
      
      res.json({ message: "Logged out successfully" });
    });
  });

  // Current user route
  app.get(`${apiPrefix}/auth/me`, (req, res) => {
    if (!req.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    res.json(req.user);
  });
  
  // Add user to request object for API routes
  app.use((req: Request, _res: Response, next: NextFunction) => {
    req.user = req.user as Express.User;
    next();
  });
};
