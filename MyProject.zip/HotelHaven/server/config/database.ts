import mongoose from 'mongoose';
import { log } from '../vite';

// MongoDB connection URI
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/hotel-booking';

// Flag to track if we're using in-memory fallback
export let usingInMemoryFallback = false;

// Connect to MongoDB
export const connectDB = async (): Promise<void> => {
  try {
    // Set mongoose options to handle deprecation warnings
    const options = {
      // useNewUrlParser and useUnifiedTopology are no longer needed in newer versions
      // but we'll retain the structure for adding other options if needed
      serverSelectionTimeoutMS: 5000, // Timeout after 5s instead of 30s
    };

    log(`Connecting to MongoDB at: ${MONGODB_URI}`, 'database');
    const conn = await mongoose.connect(MONGODB_URI, options);
    log(`MongoDB connected: ${conn.connection.host}`, 'database');
    usingInMemoryFallback = false;
  } catch (error: any) {
    log(`Error connecting to MongoDB: ${error.message}`, 'database');
    
    // More detailed error logging based on error type
    if (error.name === 'MongoServerSelectionError') {
      log('MongoDB server selection error - the MongoDB server may not be running or is unreachable', 'database');
      log('Possible solution: Make sure to whitelist your IP address in MongoDB Atlas:', 'database');
      log('1. Go to MongoDB Atlas dashboard', 'database');
      log('2. Click on "Network Access" in the left menu', 'database');
      log('3. Click "Add IP Address"', 'database');
      log('4. Choose "Allow Access From Anywhere" or add your specific IP', 'database');
      log('5. Click "Confirm"', 'database');
      log('Using fallback in-memory storage for development', 'database');
      
      // Mark that we're using the in-memory fallback
      usingInMemoryFallback = true;
    } else {
      log('Fatal database error. Make sure your MongoDB URI is correct and IP whitelist is configured.', 'database');
      // Don't exit, try to use fallback storage
      usingInMemoryFallback = true;
    }
  }
};

// Disconnect from MongoDB
export const disconnectDB = async (): Promise<void> => {
  try {
    await mongoose.disconnect();
    log('MongoDB disconnected', 'database');
  } catch (error: any) {
    log(`Error disconnecting from MongoDB: ${error.message}`, 'database');
  }
};