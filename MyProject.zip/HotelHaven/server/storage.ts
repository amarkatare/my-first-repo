import { db } from "@db";
import { 
  users, 
  rooms, 
  locations,
  bookings,
  amenities,
  roomAmenities,
  testimonials,
  subscribers,
  InsertUser,
  InsertRoom,
  InsertBooking,
  InsertLocation,
  InsertAmenity,
  InsertTestimonial,
  InsertSubscriber
} from "@shared/schema";
import { eq, and, or, desc, asc, sql, inArray, not, between, count, sum, gte, lte } from "drizzle-orm";
import { compare, hash } from "./auth";

interface RoomFilters {
  locationId?: number;
  capacity?: { min: number };
  maxPrice?: number;
  type?: string;
  checkIn?: string;
  checkOut?: string;
}

interface SortOptions {
  field: string;
  direction: string;
}

// User functions
export const storage = {
  // User operations
  getUserByUsername: async (username: string) => {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result.length > 0 ? result[0] : null;
  },

  getUserById: async (id: number) => {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result.length > 0 ? result[0] : null;
  },

  createUser: async (userData: InsertUser) => {
    const hashedPassword = await hash(userData.password);
    const userToInsert = {
      ...userData,
      password: hashedPassword,
    };
    
    const [newUser] = await db.insert(users).values(userToInsert).returning({
      id: users.id,
      username: users.username,
      fullName: users.fullName,
      email: users.email,
      phone: users.phone,
      role: users.role,
    });
    
    return newUser;
  },

  // Locations operations
  getAllLocations: async () => {
    return await db.select().from(locations).orderBy(locations.name);
  },

  getLocationById: async (id: number) => {
    const result = await db.select().from(locations).where(eq(locations.id, id)).limit(1);
    return result.length > 0 ? result[0] : null;
  },

  insertLocation: async (locationData: InsertLocation) => {
    const [newLocation] = await db.insert(locations).values(locationData).returning();
    return newLocation;
  },

  // Amenities operations
  getAllAmenities: async () => {
    return await db.select().from(amenities).orderBy(amenities.name);
  },

  getAmenityById: async (id: number) => {
    const result = await db.select().from(amenities).where(eq(amenities.id, id)).limit(1);
    return result.length > 0 ? result[0] : null;
  },

  insertAmenity: async (amenityData: InsertAmenity) => {
    const [newAmenity] = await db.insert(amenities).values(amenityData).returning();
    return newAmenity;
  },

  // Room operations
  getAllRooms: async () => {
    return await db.select().from(rooms).orderBy(rooms.name);
  },

  getRoomById: async (id: number) => {
    // Get room with its location and amenities
    const result = await db.query.rooms.findFirst({
      where: eq(rooms.id, id),
      with: {
        location: true,
        amenities: {
          with: {
            amenity: true,
          },
        },
      },
    });

    if (!result) return null;

    // Format the room data with amenities as an array
    const roomAmenities = result.amenities.map(ra => ra.amenity.name);
    
    return {
      ...result,
      amenities: roomAmenities,
      location: {
        id: result.location.id,
        name: result.location.name,
      }
    };
  },

  getFeaturedRooms: async (limit = 6) => {
    return await db.select().from(rooms)
      .where(eq(rooms.isFeatured, true))
      .limit(limit)
      .orderBy(desc(rooms.rating));
  },

  getMaxRoomPrice: async () => {
    const result = await db.select({
      maxPrice: sql<number>`MAX(${rooms.price})`,
    }).from(rooms);
    
    return result[0]?.maxPrice || 500;
  },

  getRoomsWithFilters: async (
    filters: RoomFilters,
    amenitiesFilter?: string[],
    sortOptions: SortOptions = { field: "price", direction: "asc" }
  ) => {
    // Start with a base query
    let query = db.select().from(rooms);
    
    // Apply filters
    if (filters.locationId) {
      query = query.where(eq(rooms.locationId, filters.locationId));
    }
    
    if (filters.capacity && filters.capacity.min > 0) {
      query = query.where(gte(rooms.capacity, filters.capacity.min));
    }
    
    if (filters.maxPrice && filters.maxPrice > 0) {
      query = query.where(lte(rooms.price, filters.maxPrice));
    }
    
    if (filters.type && filters.type !== "all_types") {
      query = query.where(eq(rooms.type, filters.type));
    }
    
    // Handle date availability filtering
    if (filters.checkIn && filters.checkOut) {
      // Get rooms that are not booked for the specified dates
      // This requires a more complex query with a subquery
      const bookedRoomIds = db.select({ id: bookings.roomId })
        .from(bookings)
        .where(
          and(
            eq(bookings.status, "confirmed"),
            or(
              and(
                lte(sql`${bookings.checkIn}::date`, filters.checkOut),
                gte(sql`${bookings.checkIn}::date`, filters.checkIn)
              ),
              and(
                lte(sql`${bookings.checkOut}::date`, filters.checkOut),
                gte(sql`${bookings.checkOut}::date`, filters.checkIn)
              ),
              and(
                lte(sql`${bookings.checkIn}::date`, filters.checkIn),
                gte(sql`${bookings.checkOut}::date`, filters.checkOut)
              )
            )
          )
        );
      
      query = query.where(not(inArray(rooms.id, bookedRoomIds)));
    }
    
    // Apply amenities filter if provided
    if (amenitiesFilter && amenitiesFilter.length > 0) {
      // This is a more complex query requiring a join and GROUP BY
      // We'll need to get room IDs that have all the specified amenities
      const roomsWithAmenities = db.select({ roomId: roomAmenities.roomId })
        .from(roomAmenities)
        .innerJoin(amenities, eq(roomAmenities.amenityId, amenities.id))
        .where(inArray(amenities.id, amenitiesFilter.map(Number)))
        .groupBy(roomAmenities.roomId)
        .having(count(roomAmenities.amenityId), gte(amenitiesFilter.length));
      
      query = query.where(inArray(rooms.id, roomsWithAmenities));
    }
    
    // Apply sorting
    if (sortOptions) {
      if (sortOptions.field === "price") {
        query = sortOptions.direction === "asc"
          ? query.orderBy(asc(rooms.price))
          : query.orderBy(desc(rooms.price));
      } else if (sortOptions.field === "rating") {
        query = sortOptions.direction === "asc"
          ? query.orderBy(asc(rooms.rating))
          : query.orderBy(desc(rooms.rating));
      } else if (sortOptions.field === "createdAt") {
        query = query.orderBy(desc(rooms.createdAt));
      }
    }
    
    return await query;
  },

  insertRoom: async (roomData: InsertRoom) => {
    const [newRoom] = await db.insert(rooms).values(roomData).returning();
    return newRoom;
  },

  updateRoom: async (id: number, roomData: Partial<InsertRoom>) => {
    const [updatedRoom] = await db.update(rooms)
      .set(roomData)
      .where(eq(rooms.id, id))
      .returning();
    
    return updatedRoom;
  },

  deleteRoom: async (id: number) => {
    // First check if there are any bookings for this room
    const bookingsCount = await db.select({ count: count() })
      .from(bookings)
      .where(eq(bookings.roomId, id));
    
    if (bookingsCount[0].count > 0) {
      throw new Error("Cannot delete room with existing bookings");
    }
    
    // Delete room amenities relations first
    await db.delete(roomAmenities).where(eq(roomAmenities.roomId, id));
    
    // Then delete the room
    const [deletedRoom] = await db.delete(rooms)
      .where(eq(rooms.id, id))
      .returning();
    
    return deletedRoom;
  },

  // Booking operations
  createBooking: async (bookingData: InsertBooking) => {
    // First check if the room is available for the specified dates
    const checkIn = new Date(bookingData.checkIn);
    const checkOut = new Date(bookingData.checkOut);
    
    const conflictingBookings = await db.select().from(bookings)
      .where(
        and(
          eq(bookings.roomId, bookingData.roomId),
          eq(bookings.status, "confirmed"),
          or(
            and(
              lte(bookings.checkIn, checkOut),
              gte(bookings.checkIn, checkIn)
            ),
            and(
              lte(bookings.checkOut, checkOut),
              gte(bookings.checkOut, checkIn)
            ),
            and(
              lte(bookings.checkIn, checkIn),
              gte(bookings.checkOut, checkOut)
            )
          )
        )
      );
    
    if (conflictingBookings.length > 0) {
      throw new Error("Room is not available for the selected dates");
    }
    
    // Create the booking
    const [newBooking] = await db.insert(bookings).values(bookingData).returning();
    return newBooking;
  },

  getUserBookings: async (userId: number) => {
    // Get user bookings with room information
    const userBookings = await db.select({
      id: bookings.id,
      roomId: bookings.roomId,
      roomName: rooms.name,
      roomImage: rooms.image,
      checkIn: bookings.checkIn,
      checkOut: bookings.checkOut,
      guests: bookings.guests,
      totalCost: bookings.totalCost,
      status: bookings.status,
      createdAt: bookings.createdAt,
    })
    .from(bookings)
    .innerJoin(rooms, eq(bookings.roomId, rooms.id))
    .where(eq(bookings.userId, userId))
    .orderBy(desc(bookings.createdAt));
    
    return userBookings;
  },

  getAllBookings: async () => {
    // Get all bookings with room and user information for admin
    const allBookings = await db.select({
      id: bookings.id,
      roomId: bookings.roomId,
      roomName: rooms.name,
      userId: bookings.userId,
      userName: users.fullName,
      userEmail: users.email,
      checkIn: bookings.checkIn,
      checkOut: bookings.checkOut,
      guests: bookings.guests,
      totalCost: bookings.totalCost,
      status: bookings.status,
      createdAt: bookings.createdAt,
    })
    .from(bookings)
    .innerJoin(rooms, eq(bookings.roomId, rooms.id))
    .innerJoin(users, eq(bookings.userId, users.id))
    .orderBy(desc(bookings.createdAt));
    
    return allBookings;
  },

  updateBookingStatus: async (id: number, status: string) => {
    const [updatedBooking] = await db.update(bookings)
      .set({ status })
      .where(eq(bookings.id, id))
      .returning();
    
    return updatedBooking;
  },

  // Testimonials operations
  getActiveTestimonials: async () => {
    return await db.select().from(testimonials)
      .where(eq(testimonials.isActive, true))
      .orderBy(desc(testimonials.createdAt));
  },

  insertTestimonial: async (testimonialData: InsertTestimonial) => {
    const [newTestimonial] = await db.insert(testimonials).values(testimonialData).returning();
    return newTestimonial;
  },

  // Newsletter subscribers
  addSubscriber: async (subscriberData: InsertSubscriber) => {
    // Check if email already exists
    const existingSubscriber = await db.select().from(subscribers)
      .where(eq(subscribers.email, subscriberData.email))
      .limit(1);
    
    if (existingSubscriber.length > 0) {
      return existingSubscriber[0]; // Already subscribed
    }
    
    const [newSubscriber] = await db.insert(subscribers).values(subscriberData).returning();
    return newSubscriber;
  },

  // Admin dashboard summary
  getDashboardSummary: async () => {
    // Get total rooms count
    const roomsCount = await db.select({ count: count() }).from(rooms);
    
    // Get total bookings count
    const bookingsCount = await db.select({ count: count() }).from(bookings);
    
    // Get pending bookings count
    const pendingBookingsCount = await db.select({ count: count() })
      .from(bookings)
      .where(eq(bookings.status, "pending"));
    
    // Get total revenue from confirmed bookings
    const revenueResult = await db.select({
      revenue: sql`COALESCE(SUM(${bookings.totalCost}), 0)`,
    })
    .from(bookings)
    .where(
      or(
        eq(bookings.status, "confirmed"),
        eq(bookings.status, "completed")
      )
    );
    
    // Get recent bookings
    const recentBookings = await db.select({
      id: bookings.id,
      roomName: rooms.name,
      userName: users.fullName,
      checkIn: bookings.checkIn,
      totalCost: bookings.totalCost,
    })
    .from(bookings)
    .innerJoin(rooms, eq(bookings.roomId, rooms.id))
    .innerJoin(users, eq(bookings.userId, users.id))
    .orderBy(desc(bookings.createdAt))
    .limit(5);
    
    // Get popular rooms by booking count
    const popularRooms = await db.select({
      id: rooms.id,
      name: rooms.name,
      bookingsCount: count(bookings.id),
    })
    .from(rooms)
    .leftJoin(bookings, eq(rooms.id, bookings.roomId))
    .groupBy(rooms.id, rooms.name)
    .orderBy(desc(count(bookings.id)))
    .limit(5);
    
    return {
      totalRooms: roomsCount[0].count,
      totalBookings: bookingsCount[0].count,
      pendingBookings: pendingBookingsCount[0].count,
      revenue: Number(revenueResult[0].revenue),
      recentBookings,
      popularRooms,
    };
  },
};
