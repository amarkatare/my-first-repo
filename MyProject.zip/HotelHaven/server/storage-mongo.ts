import {
  User,
  Room,
  Booking,
  Location,
  Amenity,
  Testimonial,
  Subscriber,
  IUser,
  IRoom,
  IBooking,
  ILocation,
  IAmenity,
  ITestimonial,
  ISubscriber
} from './models';
import { hash, compare } from './auth';
import mongoose from 'mongoose';
import { memoryStorage } from './storage-memory';
import { usingInMemoryFallback } from './config/database';

// Interface for room filters
interface RoomFilters {
  locationId?: string;
  capacity?: { min: number };
  maxPrice?: number;
  type?: string;
  checkIn?: string;
  checkOut?: string;
}

// Interface for sort options
interface SortOptions {
  field: string;
  direction: string;
}

// Storage service with MongoDB and fallback to in-memory storage
export const storage = {
  // User methods
  getUserByUsername: async (username: string): Promise<IUser | null> => {
    if (usingInMemoryFallback) {
      return await memoryStorage.getUserByUsername(username);
    }
    try {
      return await User.findOne({ username });
    } catch (error) {
      console.error('Error in getUserByUsername:', error);
      return await memoryStorage.getUserByUsername(username);
    }
  },

  getUserById: async (id: string): Promise<IUser | null> => {
    if (usingInMemoryFallback) {
      return await memoryStorage.getUserById(id);
    }
    try {
      return await User.findById(id);
    } catch (error) {
      console.error('Error in getUserById:', error);
      return await memoryStorage.getUserById(id);
    }
  },

  createUser: async (userData: any): Promise<IUser> => {
    if (usingInMemoryFallback) {
      return await memoryStorage.createUser(userData);
    }
    try {
      const newUser = new User(userData);
      return await newUser.save();
    } catch (error) {
      console.error('Error in createUser:', error);
      return await memoryStorage.createUser(userData);
    }
  },

  // Location methods
  getAllLocations: async (): Promise<ILocation[]> => {
    if (usingInMemoryFallback) {
      return await memoryStorage.getAllLocations();
    }
    try {
      return await Location.find({});
    } catch (error) {
      console.error('Error in getAllLocations:', error);
      return await memoryStorage.getAllLocations();
    }
  },

  getLocationById: async (id: string): Promise<ILocation | null> => {
    if (usingInMemoryFallback) {
      return await memoryStorage.getLocationById(id);
    }
    try {
      return await Location.findById(id);
    } catch (error) {
      console.error('Error in getLocationById:', error);
      return await memoryStorage.getLocationById(id);
    }
  },

  insertLocation: async (locationData: any): Promise<ILocation> => {
    if (usingInMemoryFallback) {
      return await memoryStorage.insertLocation(locationData);
    }
    try {
      const newLocation = new Location(locationData);
      return await newLocation.save();
    } catch (error) {
      console.error('Error in insertLocation:', error);
      return await memoryStorage.insertLocation(locationData);
    }
  },

  // Amenity methods
  getAllAmenities: async (): Promise<IAmenity[]> => {
    if (usingInMemoryFallback) {
      return await memoryStorage.getAllAmenities();
    }
    try {
      return await Amenity.find({});
    } catch (error) {
      console.error('Error in getAllAmenities:', error);
      return await memoryStorage.getAllAmenities();
    }
  },

  getAmenityById: async (id: string): Promise<IAmenity | null> => {
    if (usingInMemoryFallback) {
      return await memoryStorage.getAmenityById(id);
    }
    try {
      return await Amenity.findById(id);
    } catch (error) {
      console.error('Error in getAmenityById:', error);
      return await memoryStorage.getAmenityById(id);
    }
  },

  insertAmenity: async (amenityData: any): Promise<IAmenity> => {
    if (usingInMemoryFallback) {
      return await memoryStorage.insertAmenity(amenityData);
    }
    try {
      const newAmenity = new Amenity(amenityData);
      return await newAmenity.save();
    } catch (error) {
      console.error('Error in insertAmenity:', error);
      return await memoryStorage.insertAmenity(amenityData);
    }
  },

  // Room methods
  getAllRooms: async (): Promise<IRoom[]> => {
    if (usingInMemoryFallback) {
      return await memoryStorage.getAllRooms();
    }
    try {
      return await Room.find({})
        .populate('location')
        .populate('amenities');
    } catch (error) {
      console.error('Error in getAllRooms:', error);
      return await memoryStorage.getAllRooms();
    }
  },

  getRoomById: async (id: string): Promise<IRoom | null> => {
    if (usingInMemoryFallback) {
      return await memoryStorage.getRoomById(id);
    }
    try {
      return await Room.findById(id)
        .populate('location')
        .populate('amenities');
    } catch (error) {
      console.error('Error in getRoomById:', error);
      return await memoryStorage.getRoomById(id);
    }
  },

  getFeaturedRooms: async (): Promise<IRoom[]> => {
    if (usingInMemoryFallback) {
      return await memoryStorage.getFeaturedRooms();
    }
    try {
      return await Room.find({ isFeatured: true })
        .populate('location')
        .populate('amenities');
    } catch (error) {
      console.error('Error getting featured rooms:', error);
      return await memoryStorage.getFeaturedRooms();
    }
  },

  getMaxRoomPrice: async (): Promise<number> => {
    if (usingInMemoryFallback) {
      return await memoryStorage.getMaxRoomPrice();
    }
    try {
      const result = await Room.findOne({}).sort({ price: -1 }).limit(1);
      return result ? result.price : 0;
    } catch (error) {
      console.error('Error in getMaxRoomPrice:', error);
      return await memoryStorage.getMaxRoomPrice();
    }
  },

  getRoomsWithFilters: async (
    filters: RoomFilters,
    amenitiesFilter?: string[],
    sortOptions: SortOptions = { field: "price", direction: "asc" }
  ): Promise<IRoom[]> => {
    if (usingInMemoryFallback) {
      return await memoryStorage.getRoomsWithFilters(filters, amenitiesFilter, sortOptions);
    }
    
    try {
      // Build query
      let query: any = {};

      // Location filter
      if (filters.locationId) {
        query.location = filters.locationId;
      }

      // Capacity filter
      if (filters.capacity && filters.capacity.min) {
        query.capacity = { $gte: filters.capacity.min };
      }

      // Price filter
      if (filters.maxPrice) {
        query.price = { $lte: filters.maxPrice };
      }

      // Room type filter
      if (filters.type && filters.type !== 'all_types') {
        query.type = filters.type;
      }

      // Booking date availability filter
      if (filters.checkIn && filters.checkOut) {
        // Find bookings that overlap with the requested dates
        const checkIn = new Date(filters.checkIn);
        const checkOut = new Date(filters.checkOut);

        // Get rooms that are not booked during the selected period
        const bookedRoomIds = await Booking.find({
          $or: [
            { checkIn: { $lt: checkOut }, checkOut: { $gt: checkIn } },
            { checkIn: { $gte: checkIn, $lt: checkOut } },
            { checkOut: { $gt: checkIn, $lte: checkOut } }
          ],
          status: { $nin: ['cancelled'] }
        }).distinct('room');

        if (bookedRoomIds.length > 0) {
          query._id = { $nin: bookedRoomIds };
        }
      }

      // Amenities filter
      if (amenitiesFilter && amenitiesFilter.length > 0) {
        const amenityIds = amenitiesFilter.filter(id => mongoose.Types.ObjectId.isValid(id));
        if (amenityIds.length > 0) {
          query.amenities = { $all: amenityIds };
        }
      }

      // Sorting
      let sortCriteria: any = {};
      if (sortOptions.field === 'price') {
        sortCriteria.price = sortOptions.direction === 'asc' ? 1 : -1;
      } else if (sortOptions.field === 'rating') {
        sortCriteria.rating = sortOptions.direction === 'asc' ? 1 : -1;
      } else if (sortOptions.field === 'createdAt') {
        sortCriteria.createdAt = sortOptions.direction === 'asc' ? 1 : -1;
      }

      // Execute query
      return await Room.find(query)
        .populate('location')
        .populate('amenities')
        .sort(sortCriteria);
    } catch (error) {
      console.error('Error in getRoomsWithFilters:', error);
      return await memoryStorage.getRoomsWithFilters(filters, amenitiesFilter, sortOptions);
    }
  },

  insertRoom: async (roomData: any): Promise<IRoom> => {
    const newRoom = new Room(roomData);
    return await newRoom.save();
  },

  updateRoom: async (id: string, roomData: any): Promise<IRoom | null> => {
    return await Room.findByIdAndUpdate(id, roomData, { new: true })
      .populate('location')
      .populate('amenities');
  },

  deleteRoom: async (id: string): Promise<boolean> => {
    const result = await Room.findByIdAndDelete(id);
    return result !== null;
  },

  // Booking methods
  createBooking: async (bookingData: any): Promise<IBooking> => {
    const newBooking = new Booking(bookingData);
    return await newBooking.save();
  },

  getBookingById: async (id: string): Promise<IBooking | null> => {
    return await Booking.findById(id)
      .populate('user')
      .populate({
        path: 'room',
        populate: {
          path: 'location',
        }
      });
  },

  getUserBookings: async (userId: string): Promise<IBooking[]> => {
    return await Booking.find({ user: userId })
      .populate({
        path: 'room',
        populate: {
          path: 'location',
        }
      })
      .sort({ createdAt: -1 });
  },

  getAllBookings: async (): Promise<IBooking[]> => {
    return await Booking.find({})
      .populate('user')
      .populate({
        path: 'room',
        populate: {
          path: 'location',
        }
      })
      .sort({ createdAt: -1 });
  },

  updateBookingStatus: async (id: string, status: string): Promise<IBooking | null> => {
    return await Booking.findByIdAndUpdate(
      id, 
      { status }, 
      { new: true }
    )
    .populate('user')
    .populate({
      path: 'room',
      populate: {
        path: 'location',
      }
    });
  },

  // Testimonial methods
  getActiveTestimonials: async (): Promise<ITestimonial[]> => {
    return await Testimonial.find({})
      .populate('user', 'fullName')
      .sort({ createdAt: -1 });
  },

  insertTestimonial: async (testimonialData: any): Promise<ITestimonial> => {
    const newTestimonial = new Testimonial(testimonialData);
    return await newTestimonial.save();
  },

  // Subscriber methods
  addSubscriber: async (subscriberData: any): Promise<ISubscriber> => {
    const newSubscriber = new Subscriber(subscriberData);
    return await newSubscriber.save();
  },

  // Dashboard summary for admin
  getDashboardSummary: async (): Promise<any> => {
    const totalRooms = await Room.countDocuments();
    const totalBookings = await Booking.countDocuments();
    const pendingBookings = await Booking.countDocuments({ status: 'pending' });
    
    // Calculate revenue
    const confirmedBookings = await Booking.find({ 
      status: { $in: ['confirmed', 'completed'] } 
    });
    const revenue = confirmedBookings.reduce((sum, booking) => sum + booking.totalCost, 0);
    
    // Recent bookings
    const recentBookings = await Booking.find({})
      .populate('user', 'fullName')
      .populate('room', 'name')
      .sort({ createdAt: -1 })
      .limit(5);
    
    // Popular rooms
    const popularRoomIds = await Booking.aggregate([
      { $group: { _id: '$room', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 5 }
    ]);
    
    const popularRoomDetails = await Promise.all(
      popularRoomIds.map(async (item) => {
        const room = await Room.findById(item._id);
        if (!room) return null;
        
        return {
          id: room._id,
          name: room.name,
          bookingsCount: item.count
        };
      })
    );
    
    const popularRooms = popularRoomDetails.filter(room => room !== null);
    
    return {
      totalRooms,
      totalBookings,
      pendingBookings,
      revenue,
      recentBookings: recentBookings.map(booking => {
        // Handle potential MongoDB ObjectId references properly
        const room = booking.room as IRoom;
        const user = booking.user as IUser;
        
        return {
          id: booking._id,
          roomName: room.name,
          userName: user.fullName,
          checkIn: booking.checkIn,
          totalCost: booking.totalCost
        };
      }),
      popularRooms
    };
  }
};