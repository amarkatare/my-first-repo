import * as wouter from 'wouter';
console.log('Wouter exports:', Object.keys(wouter));