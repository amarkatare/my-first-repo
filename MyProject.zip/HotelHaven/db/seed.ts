import { db } from "./index";
import * as schema from "@shared/schema";
import { hash } from "../server/auth";
import { eq, and } from "drizzle-orm";

async function seed() {
  try {
    console.log("Starting database seeding...");

    // Seed admin user
    console.log("Creating admin user...");
    const adminUser = {
      username: "admin",
      password: await hash("admin123"),
      fullName: "Admin User",
      email: "admin@stayease.com",
      role: "admin"
    };

    const existingAdmin = await db.select().from(schema.users).where(eq(schema.users.username, "admin"));
    
    if (existingAdmin.length === 0) {
      await db.insert(schema.users).values(adminUser);
    }

    // Seed regular user
    console.log("Creating test user...");
    const testUser = {
      username: "testuser",
      password: await hash("password123"),
      fullName: "Test User",
      email: "test@example.com",
      role: "user"
    };

    const existingTestUser = await db.select().from(schema.users).where(eq(schema.users.username, "testuser"));
    
    if (existingTestUser.length === 0) {
      await db.insert(schema.users).values(testUser);
    }

    console.log("Database seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();