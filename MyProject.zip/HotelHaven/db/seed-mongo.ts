import { connectDB } from '../server/config/database';
import { User, Location, Amenity, Room, Testimonial } from '../server/models';
import { hash } from '../server/utils/hash';
import mongoose from 'mongoose';
import { log } from '../server/vite';

// Sample room images
const roomImages = [
  "https://images.unsplash.com/photo-1611892440504-42a792e24d32", // Luxury room
  "https://images.unsplash.com/photo-1590490360182-c33d57733427", // Suite
  "https://images.unsplash.com/photo-1598928506311-c55ded91a20c", // Deluxe room
  "https://images.unsplash.com/photo-1566665797739-1674de7a421a", // Standard room
  "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b", // Villa
  "https://images.unsplash.com/photo-1578683010236-d716f9a3f461", // Cottage
  "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4", // Premium room
  "https://images.unsplash.com/photo-1631049552057-ce19e1cda8e1", // Mountain view
  "https://images.unsplash.com/photo-1601918774946-25832a4be0d6", // Beach view
  "https://images.unsplash.com/photo-1629140727571-9b5c6f6267b4", // Riverside
  "https://images.unsplash.com/photo-1595576508898-0ad5c879a061", // Garden view
  "https://images.unsplash.com/photo-1566073771259-6a8506099945", // Penthouse
  "https://images.unsplash.com/photo-1629140727358-e3df81541ec8", // Heritage room
  "https://images.unsplash.com/photo-1550355291-bbee04a92027", // Modern room
  "https://images.unsplash.com/photo-1445991842772-097fea258e7b", // Traditional room
];

// Sample room types
const roomTypes = ['standard', 'deluxe', 'suite', 'luxury'];

// Sample room features
const roomFeatures = [
  ["King size bed", "City view", "Mini bar", "Free WiFi", "Air conditioning"],
  ["Queen size bed", "Ocean view", "Refrigerator", "Smart TV", "Bathtub"],
  ["Twin beds", "Mountain view", "Coffee maker", "Work desk", "Shower"],
  ["King size bed", "Lake view", "Dining area", "Private balcony", "Jacuzzi"],
  ["California king bed", "Garden view", "Kitchenette", "Sofa", "Floor heating"],
  ["Double bed", "Courtyard view", "Tea maker", "Seating area", "Rainfall shower"]
];

// Sample room prices in Indian Rupees (INR)
const roomPrices = [
  5000, 7500, 9000, 12000, 15000, 18000, 20000, 25000, 30000, 35000
];

// Sample amenities
const amenitiesData = [
  { 
    name: "Free WiFi", 
    description: "High-speed internet access throughout the property",
    icon: "wifi"
  },
  { 
    name: "Swimming Pool", 
    description: "Outdoor swimming pool with loungers and poolside service",
    icon: "pool"
  },
  { 
    name: "Spa", 
    description: "Full-service spa offering massages and treatments",
    icon: "spa"
  },
  { 
    name: "Fitness Center", 
    description: "24-hour gym with modern equipment",
    icon: "fitness"
  },
  { 
    name: "Restaurant", 
    description: "On-site restaurant serving local and international cuisine",
    icon: "restaurant"
  },
  { 
    name: "Room Service", 
    description: "24-hour room service for your convenience",
    icon: "room_service"
  },
  { 
    name: "Parking", 
    description: "Free parking for hotel guests",
    icon: "parking"
  },
  { 
    name: "Airport Shuttle", 
    description: "Shuttle service to and from the airport",
    icon: "airport_shuttle"
  },
  { 
    name: "Laundry", 
    description: "Laundry and dry cleaning services",
    icon: "laundry"
  },
  { 
    name: "Conference Room", 
    description: "Meeting and event spaces",
    icon: "meeting_room"
  }
];

// Indian locations data
const locationsData = [
  {
    name: "Kashmir – Jammu & Kashmir",
    description: "Experience the beauty of pristine lakes, snow-capped mountains, and vibrant gardens in the paradise on Earth."
  },
  {
    name: "Manali – Himachal Pradesh",
    description: "A picturesque hill station nestled in the mountains with breathtaking views and adventure activities."
  },
  {
    name: "Spiti Valley – Himachal Pradesh",
    description: "A desert mountain valley with stunning landscapes, ancient monasteries, and unique culture."
  },
  {
    name: "Darjeeling – West Bengal",
    description: "Famous for its tea plantations, magnificent views of the Himalayas, and the charming toy train."
  },
  {
    name: "Goa – Goa",
    description: "India's beach paradise with golden sands, vibrant nightlife, and Portuguese heritage."
  },
  {
    name: "Andaman & Nicobar Islands",
    description: "Pristine beaches, crystal clear waters, and rich marine life in this tropical paradise."
  },
  {
    name: "Gokarna – Karnataka",
    description: "A serene beach destination with pristine beaches and religious significance."
  },
  {
    name: "Jaipur – Rajasthan",
    description: "The Pink City known for its magnificent palaces, forts, and vibrant culture."
  },
  {
    name: "Udaipur – Rajasthan",
    description: "The City of Lakes with romantic settings, beautiful palaces, and rich history."
  },
  {
    name: "Jodhpur – Rajasthan",
    description: "The Blue City with the mighty Mehrangarh Fort, blue houses, and vibrant markets."
  },
  {
    name: "Varanasi – Uttar Pradesh",
    description: "One of the oldest living cities in the world with rich spiritual and cultural heritage."
  },
  {
    name: "Rishikesh – Uttarakhand",
    description: "The yoga capital with spiritual significance, nestled in the foothills of the Himalayas along the Ganges."
  },
  {
    name: "Kerala (Munnar, Alleppey)",
    description: "God's Own Country with serene backwaters, lush green hill stations, and pristine beaches."
  },
  {
    name: "Coorg – Karnataka",
    description: "Scotland of India with coffee plantations, misty hills, and cascading waterfalls."
  },
  {
    name: "Leh-Ladakh – Ladakh",
    description: "A high-altitude desert with dramatic landscapes, Buddhist monasteries, and adventure activities."
  }
];

// Sample testimonials
const testimonialsData = [
  {
    text: "Our stay at the Kashmir property was absolutely magical. The views of the mountains and the hospitality were exceptional!",
    rating: 5
  },
  {
    text: "The beach resort in Goa exceeded our expectations. The staff was attentive and the room had an amazing ocean view.",
    rating: 5
  },
  {
    text: "Spending our honeymoon in Udaipur was the best decision. The Lake Palace view from our room was breathtaking.",
    rating: 4
  },
  {
    text: "The mountain retreat in Manali offered us a perfect getaway from the city noise. The cottage was cozy and comfortable.",
    rating: 5
  },
  {
    text: "We enjoyed our family vacation in Kerala. The houseboat experience in Alleppey was unique and unforgettable.",
    rating: 4
  }
];

// Function to create a random room for a location
const createRandomRoom = (locationId: string, amenityIds: string[], index: number) => {
  const capacity = Math.floor(Math.random() * 4) + 1; // 1-4 people
  const roomType = roomTypes[Math.floor(Math.random() * roomTypes.length)];
  const price = roomPrices[Math.floor(Math.random() * roomPrices.length)];
  const features = roomFeatures[Math.floor(Math.random() * roomFeatures.length)];
  const imageIndex = index % roomImages.length;
  
  // Determine room name based on type
  let name;
  switch (roomType) {
    case 'standard':
      name = 'Standard Room';
      break;
    case 'deluxe':
      name = 'Deluxe Room';
      break;
    case 'suite':
      name = 'Luxury Suite';
      break;
    case 'luxury':
      name = 'Presidential Suite';
      break;
    default:
      name = 'Hotel Room';
  }
  
  // Add location specific details to name
  if (index % 3 === 0) {
    name = name + ' with View';
  } else if (index % 3 === 1) {
    name = name + ' with Balcony';
  }

  // Create room description
  const descriptions = [
    `Experience comfort and luxury in our ${roomType} room with stunning views and modern amenities.`,
    `Relax in our spacious ${roomType} accommodation featuring all the comforts you need for a memorable stay.`,
    `This beautiful ${roomType} room offers the perfect blend of comfort, style, and convenience.`,
    `Stay in our elegant ${roomType} room with premium furnishings and exceptional hospitality.`,
    `Our ${roomType} room provides a peaceful retreat with all the essentials for a restful vacation.`
  ];
  const description = descriptions[Math.floor(Math.random() * descriptions.length)];

  // Create details
  const details = `
This ${capacity} capacity ${roomType} offers a harmonious blend of comfort and elegance. 
Features include: ${features.join(', ')}. 

Guests can enjoy amenities such as daily housekeeping, 24-hour room service, and complimentary breakfast. 
The room is decorated with locally inspired artwork and furnishings that reflect the cultural heritage of the region.

Check-in time: 2:00 PM
Check-out time: 12:00 PM
  `;

  return {
    name,
    description,
    details,
    price,
    image: roomImages[imageIndex],
    type: roomType,
    features,
    capacity,
    location: locationId,
    amenities: amenityIds.slice(0, Math.floor(Math.random() * 5) + 3), // 3-7 amenities
    isFeatured: Math.random() > 0.7, // 30% chance to be featured
    isNewProperty: Math.random() > 0.8, // 20% chance to be new
    rating: (Math.floor(Math.random() * 10) + 35) / 10 // 3.5-4.5 rating
  };
};

// Seed function
const seedDatabase = async () => {
  try {
    // Connect to MongoDB
    await connectDB();
    
    log('Starting database seeding...', 'seed');
    
    // Clear existing data (optional - comment out if you want to keep existing data)
    await User.deleteMany({});
    await Location.deleteMany({});
    await Amenity.deleteMany({});
    await Room.deleteMany({});
    await Testimonial.deleteMany({});
    
    log('Cleared existing data', 'seed');
    
    // Create admin user
    const adminPassword = await hash('adminpassword');
    const admin = new User({
      username: 'admin',
      password: adminPassword,
      fullName: 'Admin User',
      email: 'admin@example.com',
      role: 'admin'
    });
    await admin.save();
    
    // Create regular user
    const userPassword = await hash('userpassword');
    const user = new User({
      username: 'user',
      password: userPassword,
      fullName: 'Regular User',
      email: 'user@example.com',
      role: 'user'
    });
    await user.save();
    
    log('Created users', 'seed');
    
    // Create locations
    const locations = await Location.insertMany(locationsData);
    log(`Created ${locations.length} locations`, 'seed');
    
    // Create amenities
    const amenities = await Amenity.insertMany(amenitiesData);
    log(`Created ${amenities.length} amenities`, 'seed');
    
    // Create rooms for each location
    const roomsToCreate = [];
    const amenityIds = amenities.map(amenity => amenity._id);
    
    locations.forEach((location, locationIndex) => {
      // Create 3-6 rooms per location
      const numRooms = Math.floor(Math.random() * 4) + 3;
      
      for (let i = 0; i < numRooms; i++) {
        const globalIndex = locationIndex * 10 + i; // ensure varied room types across locations
        roomsToCreate.push(createRandomRoom(location._id, amenityIds, globalIndex));
      }
    });
    
    const rooms = await Room.insertMany(roomsToCreate);
    log(`Created ${rooms.length} rooms`, 'seed');
    
    // Create testimonials
    const testimonials = [];
    for (const testimonialData of testimonialsData) {
      const userId = (Math.random() > 0.5) ? admin._id : user._id;
      testimonials.push({
        ...testimonialData,
        user: userId
      });
    }
    
    await Testimonial.insertMany(testimonials);
    log(`Created ${testimonials.length} testimonials`, 'seed');
    
    log('Database seeding completed successfully', 'seed');
    
    // Close the database connection
    await mongoose.disconnect();
    log('Database connection closed', 'seed');
    
  } catch (error) {
    log(`Error seeding database: ${error}`, 'seed');
    process.exit(1);
  }
};

// Run the seed function
seedDatabase();