import { Link } from "wouter";
import { formatPrice } from "@/lib/utils";

interface Room {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  features: string[];
  rating: number;
  isFeatured?: boolean;
  isNew?: boolean;
}

interface RoomCardProps {
  room: Room;
  className?: string;
}

const RoomCard = ({ room, className }: RoomCardProps) => {
  const { id, name, description, price, image, features, rating, isFeatured, isNew } = room;

  return (
    <div className={`group rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300 bg-white ${className}`}>
      <div className="aspect-w-16 aspect-h-9 relative">
        <img className="h-48 w-full object-cover" src={image} alt={name} />
        {isFeatured && (
          <div className="featured-badge">Popular</div>
        )}
        {isNew && (
          <div className="new-badge">New</div>
        )}
      </div>
      <div className="p-6">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-lg font-semibold text-neutral-800 font-poppins">{name}</h3>
          <div className="flex items-center">
            <svg className="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
            </svg>
            <span className="ml-1 text-sm text-neutral-500">{rating.toFixed(1)}</span>
          </div>
        </div>
        <p className="text-sm text-neutral-500 mb-4">{description}</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {features.slice(0, 3).map((feature, index) => (
            <span key={index} className="room-tag">{feature}</span>
          ))}
        </div>
        <div className="flex justify-between items-center">
          <div>
            <span className="text-lg font-bold text-neutral-800">{formatPrice(price)}</span>
            <span className="text-neutral-500 text-sm">/night</span>
          </div>
          <Link href={`/rooms/${id}`}>
            <span className="text-primary font-medium text-sm hover:text-blue-700 cursor-pointer">View Details</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default RoomCard;
