import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { formatDate, formatPrice } from "@/lib/utils";
import { Spinner } from "@/components/ui/spinner";
import { useAuth } from "@/context/AuthContext";

interface BookingFormProps {
  roomId: string;
  checkIn: string;
  checkOut: string;
  guests: number;
}

interface Room {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  features: string[];
  type: string;
  capacity: number;
}

const bookingFormSchema = z.object({
  fullName: z.string().min(3, "Full name must be at least 3 characters"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  specialRequests: z.string().optional(),
  agreeToTerms: z.boolean().refine((val) => val === true, {
    message: "You must agree to the terms to proceed",
  }),
});

type BookingFormValues = z.infer<typeof bookingFormSchema>;

const BookingForm = ({ roomId, checkIn, checkOut, guests }: BookingFormProps) => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const [totalCost, setTotalCost] = useState<number>(0);

  // Fetch room details
  const { data: room, isLoading: isLoadingRoom } = useQuery<Room>({
    queryKey: [`/api/rooms/${roomId}`],
  });
  
  // Calculate total cost when room data changes
  useEffect(() => {
    if (room) {
      const checkInDate = new Date(checkIn);
      const checkOutDate = new Date(checkOut);
      const nights = Math.ceil((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24));
      setTotalCost(room.price * nights);
    }
  }, [room, checkIn, checkOut]);

  const form = useForm<BookingFormValues>({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      email: user?.email || "",
      phone: user?.phone || "",
      specialRequests: "",
      agreeToTerms: false,
    },
  });

  const createBookingMutation = useMutation({
    mutationFn: async (data: BookingFormValues) => {
      const booking = {
        ...data,
        roomId,
        checkIn,
        checkOut,
        guests,
        totalCost,
      };
      return await apiRequest("POST", "/api/bookings", booking);
    },
    onSuccess: async (response) => {
      const data = await response.json();
      toast({
        title: "Booking Successful!",
        description: "Your room has been booked successfully.",
      });
      navigate(`/booking/confirmation/${data.id}`);
      queryClient.invalidateQueries({ queryKey: ["/api/user/bookings"] });
    },
    onError: (error) => {
      toast({
        title: "Booking Failed",
        description: error.message || "There was an error with your booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: BookingFormValues) => {
    createBookingMutation.mutate(data);
  };

  if (isLoadingRoom) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <Spinner size="lg" />
      </div>
    );
  }

  if (!room) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p>Room not found or no longer available.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl">Complete Your Booking</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="bg-secondary p-4 rounded-md mb-6">
          <h3 className="font-semibold mb-2">{room.name}</h3>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>
              <span className="text-neutral-500">Check-in:</span>
              <span className="ml-2 font-medium">{formatDate(checkIn)}</span>
            </div>
            <div>
              <span className="text-neutral-500">Check-out:</span>
              <span className="ml-2 font-medium">{formatDate(checkOut)}</span>
            </div>
            <div>
              <span className="text-neutral-500">Guests:</span>
              <span className="ml-2 font-medium">{guests}</span>
            </div>
            <div>
              <span className="text-neutral-500">Rate:</span>
              <span className="ml-2 font-medium">{formatPrice(room.price)}/night</span>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-neutral-200">
            <div className="flex justify-between items-center">
              <span className="font-semibold">Total Cost:</span>
              <span className="text-lg font-bold">{formatPrice(totalCost)}</span>
            </div>
          </div>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="fullName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <Input placeholder="John Doe" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input placeholder="john@example.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone Number</FormLabel>
                  <FormControl>
                    <Input placeholder="+1 (555) 123-4567" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="specialRequests"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Special Requests (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="Any special requests?" {...field} />
                  </FormControl>
                  <FormDescription>
                    Let us know if you have any special requirements for your stay.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="agreeToTerms"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 py-4">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>
                      I agree to the <a href="#" className="text-primary underline">terms and conditions</a> and <a href="#" className="text-primary underline">privacy policy</a>
                    </FormLabel>
                    <FormMessage />
                  </div>
                </FormItem>
              )}
            />
          </form>
        </Form>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          onClick={() => window.history.back()}
        >
          Back
        </Button>
        <Button
          type="submit"
          onClick={form.handleSubmit(onSubmit)}
          disabled={createBookingMutation.isPending}
        >
          {createBookingMutation.isPending ? (
            <>
              <Spinner className="mr-2" size="sm" />
              Processing...
            </>
          ) : (
            "Complete Booking"
          )}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default BookingForm;
