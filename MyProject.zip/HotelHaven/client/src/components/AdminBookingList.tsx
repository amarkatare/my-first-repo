import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDate, formatPrice } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Spinner } from "@/components/ui/spinner";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useState } from "react";

interface Booking {
  id: string;
  roomId: string;
  roomName: string;
  userId: string;
  userName: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  totalCost: number;
  status: "pending" | "confirmed" | "cancelled" | "completed";
  createdAt: string;
}

const AdminBookingList = () => {
  const { toast } = useToast();
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>("all_statuses");

  const { data: bookings, isLoading } = useQuery<Booking[]>({
    queryKey: ["/api/bookings/all"],
  });

  const updateBookingStatusMutation = useMutation({
    mutationFn: async ({
      id,
      status,
    }: {
      id: string;
      status: "confirmed" | "cancelled" | "completed";
    }) => {
      return await apiRequest("PATCH", `/api/bookings/${id}/status`, { status });
    },
    onSuccess: () => {
      toast({
        title: "Booking Updated",
        description: "The booking status has been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/bookings/all"] });
      setIsDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update booking status",
        variant: "destructive",
      });
    },
  });

  const filteredBookings = bookings?.filter((booking) => {
    if (statusFilter === "all_statuses") return true;
    return booking.status === statusFilter;
  });

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "pending":
        return "warning";
      case "confirmed":
        return "success";
      case "cancelled":
        return "destructive";
      case "completed":
        return "secondary";
      default:
        return "default";
    }
  };

  const handleViewDetails = (booking: Booking) => {
    setSelectedBooking(booking);
    setIsDialogOpen(true);
  };

  const handleUpdateStatus = (status: "confirmed" | "cancelled" | "completed") => {
    if (selectedBooking) {
      updateBookingStatusMutation.mutate({
        id: selectedBooking.id,
        status,
      });
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Bookings</CardTitle>
        <Select
          value={statusFilter}
          onValueChange={setStatusFilter}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all_statuses">All Statuses</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="confirmed">Confirmed</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center my-8">
            <Spinner size="lg" />
          </div>
        ) : filteredBookings && filteredBookings.length > 0 ? (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Room</TableHead>
                  <TableHead>Guest</TableHead>
                  <TableHead>Check In</TableHead>
                  <TableHead>Check Out</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredBookings.map((booking) => (
                  <TableRow key={booking.id}>
                    <TableCell className="font-medium">{booking.id.substring(0, 8)}...</TableCell>
                    <TableCell>{booking.roomName}</TableCell>
                    <TableCell>{booking.userName}</TableCell>
                    <TableCell>{formatDate(booking.checkIn)}</TableCell>
                    <TableCell>{formatDate(booking.checkOut)}</TableCell>
                    <TableCell>{formatPrice(booking.totalCost)}</TableCell>
                    <TableCell>
                      <Badge variant={getStatusBadgeVariant(booking.status)}>
                        {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleViewDetails(booking)}
                      >
                        Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="text-center p-8 text-muted-foreground">
            No bookings found.
          </div>
        )}
      </CardContent>

      {/* Booking Details Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Booking Details</DialogTitle>
            <DialogDescription>
              Booking #{selectedBooking?.id?.substring(0, 8)}
            </DialogDescription>
          </DialogHeader>
          {selectedBooking && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Room</h3>
                  <p className="text-base">{selectedBooking.roomName}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Guest</h3>
                  <p className="text-base">{selectedBooking.userName}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Check In</h3>
                  <p className="text-base">{formatDate(selectedBooking.checkIn)}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Check Out</h3>
                  <p className="text-base">{formatDate(selectedBooking.checkOut)}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Guests</h3>
                  <p className="text-base">{selectedBooking.guests}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Total Cost</h3>
                  <p className="text-base font-semibold">{formatPrice(selectedBooking.totalCost)}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Status</h3>
                  <Badge variant={getStatusBadgeVariant(selectedBooking.status)} className="mt-1">
                    {selectedBooking.status.charAt(0).toUpperCase() + selectedBooking.status.slice(1)}
                  </Badge>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Created</h3>
                  <p className="text-base">{formatDate(selectedBooking.createdAt)}</p>
                </div>
              </div>

              <div className="pt-4 border-t">
                <h3 className="text-sm font-medium mb-2">Update Status</h3>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleUpdateStatus("confirmed")}
                    disabled={
                      selectedBooking.status === "confirmed" ||
                      selectedBooking.status === "completed" ||
                      selectedBooking.status === "cancelled" ||
                      updateBookingStatusMutation.isPending
                    }
                  >
                    Confirm
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleUpdateStatus("completed")}
                    disabled={
                      selectedBooking.status === "completed" ||
                      selectedBooking.status === "cancelled" ||
                      updateBookingStatusMutation.isPending
                    }
                  >
                    Complete
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleUpdateStatus("cancelled")}
                    disabled={
                      selectedBooking.status === "cancelled" ||
                      selectedBooking.status === "completed" ||
                      updateBookingStatusMutation.isPending
                    }
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="secondary"
              onClick={() => setIsDialogOpen(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default AdminBookingList;
