import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

interface Testimonial {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  text: string;
}

const Testimonials = () => {
  const { data: testimonials, isLoading } = useQuery<Testimonial[]>({
    queryKey: ["/api/testimonials"],
  });

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }).map((_, i) => (
      <svg
        key={i}
        className={`w-4 h-4 ${
          i < rating ? "text-yellow-400" : "text-yellow-400 opacity-30"
        }`}
        fill="currentColor"
        viewBox="0 0 20 20"
      >
        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
      </svg>
    ));
  };

  // Function to get the avatar color class based on name
  const getAvatarColorClass = (name: string) => {
    const colors = ["bg-primary", "bg-accent", "bg-success", "bg-warning"];
    const charCode = name.charCodeAt(0);
    return colors[charCode % colors.length];
  };

  return (
    <div className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold tracking-tight text-neutral-800 sm:text-4xl font-poppins">
            What Our Guests Say
          </h2>
          <p className="mt-3 max-w-2xl mx-auto text-xl text-neutral-500 sm:mt-4 font-inter">
            Hear about the experiences of our valued guests
          </p>
        </div>

        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {isLoading ? (
            // Skeleton loading state
            Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="bg-secondary rounded-lg p-6 shadow-sm">
                <div className="flex items-center mb-4">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="ml-4">
                    <Skeleton className="h-5 w-32 mb-1" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
                <Skeleton className="h-20 w-full" />
              </div>
            ))
          ) : (
            testimonials?.map((testimonial) => (
              <div key={testimonial.id} className="bg-secondary rounded-lg p-6 shadow-sm">
                <div className="flex items-center mb-4">
                  {testimonial.avatar ? (
                    <img
                      src={testimonial.avatar}
                      alt={testimonial.name}
                      className="h-10 w-10 rounded-full object-cover"
                    />
                  ) : (
                    <div
                      className={`h-10 w-10 rounded-full ${getAvatarColorClass(
                        testimonial.name
                      )} flex items-center justify-center text-white font-bold text-lg`}
                    >
                      {testimonial.name.charAt(0)}
                    </div>
                  )}
                  <div className="ml-4">
                    <h4 className="text-lg font-semibold text-neutral-800 font-poppins">
                      {testimonial.name}
                    </h4>
                    <div className="flex items-center">
                      {renderStars(testimonial.rating)}
                    </div>
                  </div>
                </div>
                <p className="text-neutral-600">{testimonial.text}</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Testimonials;
