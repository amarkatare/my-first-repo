import { cn } from "@/lib/utils";

interface HeroSectionProps {
  heroImage: string;
  heroTitle: string;
  heroSubtitle: string;
  className?: string;
}

const HeroSection = ({
  heroImage,
  heroTitle,
  heroSubtitle,
  className,
}: HeroSectionProps) => {
  return (
    <div className={cn("relative bg-neutral-800", className)}>
      <div className="absolute inset-0">
        <img
          className="w-full h-full object-cover"
          src={heroImage}
          alt="Hotel view"
        />
        <div className="hero-overlay"></div>
      </div>
      <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl font-poppins">
          {heroTitle}
        </h1>
        <p className="mt-6 text-xl text-white max-w-3xl font-inter">
          {heroSubtitle}
        </p>
      </div>
    </div>
  );
};

export default HeroSection;
