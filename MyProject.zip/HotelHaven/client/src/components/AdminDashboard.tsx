import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import AdminRoomList from "@/components/AdminRoomList";
import AdminBookingList from "@/components/AdminBookingList";
import { formatPrice } from "@/lib/utils";
import { Spinner } from "@/components/ui/spinner";

interface DashboardSummary {
  totalRooms: number;
  totalBookings: number;
  pendingBookings: number;
  revenue: number;
  recentBookings: Array<{
    id: string;
    roomName: string;
    userName: string;
    checkIn: string;
    totalCost: number;
  }>;
  popularRooms: Array<{
    id: string;
    name: string;
    bookingsCount: number;
  }>;
}

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");

  const { data: dashboardSummary, isLoading } = useQuery<DashboardSummary>({
    queryKey: ["/api/admin/dashboard-summary"],
  });

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Admin Dashboard</h1>
      <p className="text-muted-foreground mb-8">
        Manage rooms, bookings, and view summary statistics.
      </p>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="rooms">Rooms</TabsTrigger>
          <TabsTrigger value="bookings">Bookings</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          {isLoading ? (
            <div className="flex justify-center my-12">
              <Spinner size="lg" />
            </div>
          ) : dashboardSummary ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Rooms</CardTitle>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="w-5 h-5 text-muted-foreground"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M2.25 21h19.5m-18-18v18m10.5-18v18m6-13.5V21M6.75 6.75h.75m-.75 3h.75m-.75 3h.75m3-6h.75m-.75 3h.75m-.75 3h.75M6.75 21v-3.375c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21M3 3h12m-.75 4.5H21m-3.75 3.75h.008v.008h-.008v-.008zm0 3h.008v.008h-.008v-.008zm0 3h.008v.008h-.008v-.008z"
                    />
                  </svg>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{dashboardSummary.totalRooms}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Available for booking
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Bookings</CardTitle>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="w-5 h-5 text-muted-foreground"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5m-9-6h.008v.008H12v-.008zM12 15h.008v.008H12V15zm0 2.25h.008v.008H12v-.008zM9.75 15h.008v.008H9.75V15zm0 2.25h.008v.008H9.75v-.008zM7.5 15h.008v.008H7.5V15zm0 2.25h.008v.008H7.5v-.008zm6.75-4.5h.008v.008h-.008v-.008zm0 2.25h.008v.008h-.008V15zm0 2.25h.008v.008h-.008v-.008zm2.25-4.5h.008v.008H16.5v-.008zm0 2.25h.008v.008H16.5V15z"
                    />
                  </svg>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{dashboardSummary.totalBookings}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Lifetime reservations
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pending Bookings</CardTitle>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="w-5 h-5 text-muted-foreground"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{dashboardSummary.pendingBookings}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Awaiting confirmation
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth={1.5}
                    stroke="currentColor"
                    className="w-5 h-5 text-muted-foreground"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M12 6v12m-3-2.818l.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatPrice(dashboardSummary.revenue)}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Total confirmed bookings
                  </p>
                </CardContent>
              </Card>

              {/* Recent Bookings Card */}
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Recent Bookings</CardTitle>
                  <CardDescription>Recent booking activity</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {dashboardSummary.recentBookings.map((booking) => (
                      <div key={booking.id} className="flex items-center">
                        <div className="w-2 h-2 rounded-full bg-primary mr-3" />
                        <div className="flex-1 space-y-1">
                          <p className="text-sm font-medium leading-none">
                            {booking.roomName}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Booked by {booking.userName}
                          </p>
                        </div>
                        <div className="font-medium">{formatPrice(booking.totalCost)}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Popular Rooms Card */}
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Popular Rooms</CardTitle>
                  <CardDescription>Most booked rooms</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {dashboardSummary.popularRooms.map((room) => (
                      <div key={room.id} className="flex items-center">
                        <div className="w-2 h-2 rounded-full bg-primary mr-3" />
                        <div className="flex-1">
                          <p className="text-sm font-medium leading-none">
                            {room.name}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-medium">
                            {room.bookingsCount} bookings
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              Failed to load dashboard data. Please try again later.
            </div>
          )}
        </TabsContent>

        <TabsContent value="rooms">
          <AdminRoomList />
        </TabsContent>

        <TabsContent value="bookings">
          <AdminBookingList />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminDashboard;
