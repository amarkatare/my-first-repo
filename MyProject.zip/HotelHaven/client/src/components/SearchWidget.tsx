import { useState } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQuery } from "@tanstack/react-query";
import { addDays } from "@/lib/utils";

interface Location {
  id: string;
  name: string;
}

const searchFormSchema = z.object({
  locationId: z.string().optional(),
  checkIn: z.string().min(1, "Check-in date is required"),
  checkOut: z.string().min(1, "Check-out date is required"),
  guests: z.string().min(1, "Number of guests is required"),
});

type SearchFormValues = z.infer<typeof searchFormSchema>;

const SearchWidget = () => {
  const [, navigate] = useLocation();
  const today = new Date();
  const tomorrow = addDays(today, 1);
  
  // Format dates for the date inputs
  const formatDateForInput = (date: Date) => {
    return date.toISOString().split('T')[0];
  };

  const form = useForm<SearchFormValues>({
    resolver: zodResolver(searchFormSchema),
    defaultValues: {
      locationId: "",
      checkIn: formatDateForInput(today),
      checkOut: formatDateForInput(tomorrow),
      guests: "2",
    },
  });

  // Fetch locations from the API
  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: ["/api/locations"],
  });

  // Handle search submission
  const onSubmit = (data: SearchFormValues) => {
    const searchParams = new URLSearchParams();
    if (data.locationId && data.locationId !== "all_locations") {
      searchParams.set("location", data.locationId);
    }
    searchParams.set("checkIn", data.checkIn);
    searchParams.set("checkOut", data.checkOut);
    searchParams.set("guests", data.guests);
    
    navigate(`/rooms?${searchParams.toString()}`);
  };

  return (
    <div className="relative max-w-5xl mx-auto px-4 sm:px-6 -mt-16 z-10">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="px-4 py-5 sm:p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
                <FormField
                  control={form.control}
                  name="locationId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-neutral-500">Location</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="w-full bg-white border border-neutral-100 rounded-md py-2 px-3 shadow-sm focus:outline-none focus:ring-primary focus:border-primary">
                            <SelectValue placeholder="Any location" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="all_locations">Any location</SelectItem>
                          {locations.map((location) => (
                            <SelectItem key={location.id} value={location.id}>
                              {location.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="checkIn"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-neutral-500">Check in</FormLabel>
                      <FormControl>
                        <Input
                          type="date"
                          min={formatDateForInput(today)}
                          className="date-picker-input"
                          {...field}
                          onChange={(e) => {
                            field.onChange(e);
                            
                            // Update checkout to be after checkin
                            const checkInDate = new Date(e.target.value);
                            const checkOutDate = new Date(form.getValues().checkOut);
                            
                            if (checkOutDate <= checkInDate) {
                              const nextDay = new Date(checkInDate);
                              nextDay.setDate(nextDay.getDate() + 1);
                              form.setValue("checkOut", formatDateForInput(nextDay));
                            }
                          }}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="checkOut"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-neutral-500">Check out</FormLabel>
                      <FormControl>
                        <Input
                          type="date"
                          min={form.watch("checkIn")}
                          className="date-picker-input"
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="guests"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-medium text-neutral-500">Guests</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger className="w-full bg-white border border-neutral-100 rounded-md py-2 px-3 shadow-sm focus:outline-none focus:ring-primary focus:border-primary">
                            <SelectValue placeholder="Select guests" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="1">1 Guest</SelectItem>
                          <SelectItem value="2">2 Guests</SelectItem>
                          <SelectItem value="3">3 Guests</SelectItem>
                          <SelectItem value="4">4+ Guests</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />
              </div>
              <div className="mt-5 text-right">
                <Button 
                  type="submit" 
                  className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-primary hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                >
                  Search Rooms
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
};

export default SearchWidget;
