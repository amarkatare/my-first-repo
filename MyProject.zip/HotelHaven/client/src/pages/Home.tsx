import { useEffect } from "react";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import SearchWidget from "@/components/SearchWidget";
import FeaturedRooms from "@/components/FeaturedRooms";
import Amenities from "@/components/Amenities";
import Testimonials from "@/components/Testimonials";
import Newsletter from "@/components/Newsletter";
import Footer from "@/components/Footer";

const Home = () => {
  // Update page title on component mount
  useEffect(() => {
    document.title = "StayEase - Find Your Perfect Stay";
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <HeroSection
          heroImage="https://images.unsplash.com/photo-1571896349842-33c89424de2d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&q=80"
          heroTitle="Find Your Perfect Stay"
          heroSubtitle="Discover luxury accommodations with breathtaking views and exceptional service for your next getaway."
        />
        <SearchWidget />
        <FeaturedRooms />
        <Amenities />
        <Testimonials />
        <Newsletter />
      </main>
      <Footer />
    </div>
  );
};

export default Home;
