import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/Navbar";
import RoomCard from "@/components/RoomCard";
import RoomFilters from "@/components/RoomFilters";
import Footer from "@/components/Footer";
import { Spinner } from "@/components/ui/spinner";
import { Button } from "@/components/ui/button";

interface Room {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  features: string[];
  rating: number;
  type: string;
  capacity: number;
  amenities: string[];
  isFeatured: boolean;
  isNew: boolean;
}

interface Amenity {
  id: string;
  name: string;
}

const Rooms = () => {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1]);
  
  const [filters, setFilters] = useState({
    priceRange: [500], // Default max price
    roomType: searchParams.get("roomType") || "",
    sortBy: "price-asc",
    amenities: [],
  });

  // Extract search params
  const locationId = searchParams.get("location") || "";
  const checkIn = searchParams.get("checkIn") || "";
  const checkOut = searchParams.get("checkOut") || "";
  const guests = searchParams.get("guests") || "";

  // Fetch all amenities for the filter panel
  const { data: amenities = [] } = useQuery<Amenity[]>({
    queryKey: ["/api/amenities"],
  });

  // Fetch maximum room price for the price range slider
  const { data: maxPriceData } = useQuery<{ maxPrice: number }>({
    queryKey: ["/api/rooms/max-price"],
  });

  // Construct the query string for the rooms API
  const buildRoomsQueryString = () => {
    const params = new URLSearchParams();
    if (locationId) params.append("locationId", locationId);
    if (checkIn) params.append("checkIn", checkIn);
    if (checkOut) params.append("checkOut", checkOut);
    if (guests) params.append("guests", guests);
    if (filters.roomType && filters.roomType !== "all_types") {
      params.append("roomType", filters.roomType);
    }
    if (filters.priceRange && filters.priceRange.length > 0) {
      params.append("maxPrice", filters.priceRange[0].toString());
    }
    if (filters.amenities && filters.amenities.length > 0) {
      filters.amenities.forEach(amenity => params.append("amenities", amenity));
    }
    params.append("sortBy", filters.sortBy);
    
    return params.toString();
  };

  // Build query params once so it's stable across renders
  const queryString = buildRoomsQueryString();
  
  // Fetch rooms based on filters with a stable key
  const {
    data: rooms = [],
    isLoading,
  } = useQuery<Room[]>({
    queryKey: ['/api/rooms', queryString],
    enabled: true,
  });

  // Update the filters when user interacts with the filter panel
  const handleFilterChange = (newFilters: any) => {
    setFilters(newFilters);
  };

  // Update page title on component mount
  useEffect(() => {
    document.title = "Rooms - StayEase";
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow bg-background py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold mb-2">Available Rooms</h1>
          <p className="text-muted-foreground mb-6">
            Find the perfect accommodation for your stay
            {checkIn && checkOut && (
              <span>
                {" "}
                from <strong>{new Date(checkIn).toLocaleDateString()}</strong> to{" "}
                <strong>{new Date(checkOut).toLocaleDateString()}</strong>
              </span>
            )}
            {guests && <span> for <strong>{guests}</strong> guests</span>}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="md:col-span-1">
              <RoomFilters
                onFilterChange={handleFilterChange}
                amenities={amenities}
                maxPrice={maxPriceData?.maxPrice || 500}
              />
            </div>
            <div className="md:col-span-3">
              {isLoading ? (
                <div className="flex justify-center items-center min-h-[400px]">
                  <Spinner size="lg" />
                </div>
              ) : rooms.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {rooms.map((room) => (
                    <RoomCard key={room.id} room={room} />
                  ))}
                </div>
              ) : (
                <div className="bg-white rounded-lg shadow p-8 text-center">
                  <h3 className="text-xl font-semibold mb-2">No Rooms Found</h3>
                  <p className="text-muted-foreground mb-6">
                    We couldn't find any rooms matching your search criteria. Try adjusting your filters or dates.
                  </p>
                  <Button onClick={() => setFilters({
                    priceRange: [maxPriceData?.maxPrice || 500],
                    roomType: "all_types",
                    sortBy: "price-asc",
                    amenities: [],
                  })}>
                    Reset Filters
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Rooms;
