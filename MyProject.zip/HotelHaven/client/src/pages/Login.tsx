import { useEffect } from "react";
import { useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { LoginForm } from "@/components/AuthForms";

const Login = () => {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const redirect = searchParams.get("redirect") || "/";

  // Update page title on component mount
  useEffect(() => {
    document.title = "Login - StayEase";
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow flex items-center justify-center bg-background py-12">
        <div className="w-full max-w-md px-4">
          <LoginForm />
          {redirect && redirect !== "/" && (
            <div className="mt-4 text-center text-sm text-muted-foreground">
              You'll be redirected after login.
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Login;
