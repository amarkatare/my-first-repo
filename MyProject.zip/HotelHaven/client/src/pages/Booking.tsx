import { useEffect } from "react";
import { useParams, useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BookingForm from "@/components/BookingForm";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";

const Booking = () => {
  const { id } = useParams();
  const [location, navigate] = useLocation();
  const { user } = useAuth();

  // Parse query parameters
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const checkIn = searchParams.get("checkIn") || "";
  const checkOut = searchParams.get("checkOut") || "";
  const guests = Number(searchParams.get("guests") || "1");

  // Update page title on component mount
  useEffect(() => {
    document.title = "Complete Your Booking - StayEase";
  }, []);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!user) {
      navigate(`/login?redirect=${encodeURIComponent(location)}`);
    }
  }, [user, navigate, location]);

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold">Authentication Required</h2>
            <p className="mt-2 text-muted-foreground">
              You need to be logged in to make a booking.
            </p>
            <Button 
              onClick={() => navigate(`/login?redirect=${encodeURIComponent(location)}`)} 
              className="mt-4"
            >
              Log In
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  // Validate booking parameters
  if (!id || !checkIn || !checkOut || !guests) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold">Invalid Booking Request</h2>
            <p className="mt-2 text-muted-foreground">
              Please select a room, dates, and number of guests before booking.
            </p>
            <Button onClick={() => navigate("/rooms")} className="mt-4">
              Browse Rooms
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow bg-background py-8">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold mb-6">Complete Your Booking</h1>
          <BookingForm 
            roomId={id} 
            checkIn={checkIn} 
            checkOut={checkOut} 
            guests={guests} 
          />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Booking;
