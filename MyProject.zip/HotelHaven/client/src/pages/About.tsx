import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useEffect } from "react";

const About = () => {
  // Update page title on component mount
  useEffect(() => {
    document.title = "About Us - StayEase";
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow bg-background py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-neutral-900 mb-4">About StayEase</h1>
            <p className="text-lg text-neutral-600 max-w-3xl mx-auto">
              Discover the story behind our luxury hotel booking platform and our commitment to providing exceptional stays.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
            <div className="flex flex-col justify-center">
              <h2 className="text-2xl font-bold text-neutral-900 mb-4">Our Story</h2>
              <p className="text-neutral-700 mb-4">
                Founded in 2020 at ADCET, Ashta, StayEase started with a simple mission: to create a seamless and enjoyable hotel booking experience. What began as a small student project has grown into a trusted platform connecting travelers with exceptional accommodations across India.
              </p>
              <p className="text-neutral-700 mb-4">
                Our team of passionate engineers and hospitality experts from ADCET work tirelessly to curate a selection of the finest hotels, ensuring that every stay booked through our platform exceeds expectations.
              </p>
              <p className="text-neutral-700">
                Over the years, we've helped thousands of guests create unforgettable memories, and we continue to innovate and improve our services to make hotel booking as effortless as possible.
              </p>
            </div>
            <div className="rounded-lg overflow-hidden shadow-lg">
              <img 
                src="https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1080&q=80" 
                alt="Luxury hotel lobby" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8 mb-16">
            <h2 className="text-2xl font-bold text-neutral-900 mb-6 text-center">Our Values</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-8 h-8">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Excellence</h3>
                <p className="text-neutral-600">We strive for excellence in every aspect of our service, from the quality of our hotel partners to the user experience on our platform.</p>
              </div>
              <div className="text-center">
                <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-8 h-8">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Trust</h3>
                <p className="text-neutral-600">We build trust with our users through transparency, reliability, and a commitment to customer satisfaction.</p>
              </div>
              <div className="text-center">
                <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-8 h-8">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2">Innovation</h3>
                <p className="text-neutral-600">We continuously innovate to improve our platform and offer cutting-edge features that enhance the booking experience.</p>
              </div>
            </div>
          </div>

          <div className="mb-16">
            <h2 className="text-2xl font-bold text-neutral-900 mb-6 text-center">Our Team</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                {
                  name: "Amar Katare",
                  position: "CEO & Founder",
                  image: "https://images.unsplash.com/photo-1531891570158-e71b35a485bc?ixlib=rb-4.0.3&auto=format&fit=crop&w=256&q=80"
                },
                {
                  name: "Rajesh Sharma",
                  position: "CTO",
                  image: "https://images.unsplash.com/photo-1582233479366-6d38bc390a08?ixlib=rb-4.0.3&auto=format&fit=crop&w=256&q=80"
                },
                {
                  name: "Priya Patel",
                  position: "Head of Operations",
                  image: "https://images.unsplash.com/photo-1567303314286-6735a4ad9d42?ixlib=rb-4.0.3&auto=format&fit=crop&w=256&q=80"
                },
                {
                  name: "Vikram Mehta",
                  position: "Director of Marketing",
                  image: "https://images.unsplash.com/photo-1463453091185-61582044d556?ixlib=rb-4.0.3&auto=format&fit=crop&w=256&q=80"
                }
              ].map((member, index) => (
                <div key={index} className="bg-white rounded-lg shadow overflow-hidden">
                  <img src={member.image} alt={member.name} className="w-full h-64 object-cover object-center" />
                  <div className="p-4">
                    <h3 className="text-lg font-semibold text-neutral-900">{member.name}</h3>
                    <p className="text-neutral-600">{member.position}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default About;