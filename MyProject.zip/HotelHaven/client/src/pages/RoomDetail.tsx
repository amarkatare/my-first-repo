import { useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { formatPrice } from "@/lib/utils";
import { Spinner } from "@/components/ui/spinner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalendarIcon, Users, Check } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { addDays, format } from "date-fns";
import { useState } from "react";
import { useAuth } from "@/context/AuthContext";

interface Room {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  features: string[];
  amenities: string[];
  rating: number;
  type: string;
  capacity: number;
  details: string;
  location: {
    id: string;
    name: string;
  };
}

const RoomDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [location, navigate] = useLocation();

  // Parse query parameters if any
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const initialCheckIn = searchParams.get("checkIn");
  const initialCheckOut = searchParams.get("checkOut");
  const initialGuests = searchParams.get("guests") || "2";

  // Initialize state with query parameters if available
  const [checkInDate, setCheckInDate] = useState<Date | undefined>(
    initialCheckIn ? new Date(initialCheckIn) : undefined
  );
  const [checkOutDate, setCheckOutDate] = useState<Date | undefined>(
    initialCheckOut ? new Date(initialCheckOut) : undefined
  );
  const [guests, setGuests] = useState(initialGuests);

  // Fetch room data
  const { data: room, isLoading } = useQuery<Room>({
    queryKey: [`/api/rooms/${id}`],
  });

  // Update page title when room data is loaded
  useEffect(() => {
    if (room) {
      document.title = `${room.name} - StayEase`;
    } else {
      document.title = "Room Details - StayEase";
    }
  }, [room]);

  // Handle check-in date selection
  const handleCheckInSelect = (date: Date | undefined) => {
    setCheckInDate(date);
    
    // If check-out date is before new check-in date, reset it
    if (date && checkOutDate && checkOutDate <= date) {
      setCheckOutDate(undefined);
    }
  };

  // Handle booking button click
  const handleBookNow = () => {
    if (!user) {
      // If user is not logged in, redirect to login page
      navigate(`/login?redirect=/rooms/${id}${location.split("?")[1] ? `?${location.split("?")[1]}` : ""}`);
      return;
    }
    
    if (!checkInDate || !checkOutDate) {
      alert("Please select both check-in and check-out dates");
      return;
    }

    const bookingParams = new URLSearchParams();
    bookingParams.set("checkIn", checkInDate.toISOString().split("T")[0]);
    bookingParams.set("checkOut", checkOutDate.toISOString().split("T")[0]);
    bookingParams.set("guests", guests);

    navigate(`/booking/${id}?${bookingParams.toString()}`);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <Spinner size="lg" />
        </main>
        <Footer />
      </div>
    );
  }

  if (!room) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold">Room Not Found</h2>
            <p className="mt-2 text-muted-foreground">
              The room you're looking for doesn't exist or has been removed.
            </p>
            <Button onClick={() => navigate("/rooms")} className="mt-4">
              Browse Available Rooms
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Room Details Section */}
            <div className="lg:col-span-2">
              <div className="mb-4">
                <h1 className="text-3xl font-bold mb-2">{room.name}</h1>
                <div className="flex items-center text-sm mb-4">
                  <div className="flex items-center">
                    <svg className="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                    <span className="ml-1 text-muted-foreground">{room.rating.toFixed(1)}</span>
                  </div>
                  <span className="mx-2 text-muted-foreground">•</span>
                  <span className="text-muted-foreground">{room.type}</span>
                  <span className="mx-2 text-muted-foreground">•</span>
                  <span className="text-muted-foreground">{room.location.name}</span>
                </div>
              </div>

              <div className="mb-8">
                <img 
                  src={room.image} 
                  alt={room.name} 
                  className="w-full h-96 object-cover rounded-lg"
                />
              </div>

              <Tabs defaultValue="overview">
                <TabsList className="mb-4">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="amenities">Amenities</TabsTrigger>
                  <TabsTrigger value="details">Details</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-4">
                  <div>
                    <h2 className="text-xl font-semibold mb-2">Description</h2>
                    <p className="text-muted-foreground">{room.description}</p>
                  </div>

                  <div>
                    <h2 className="text-xl font-semibold mb-2">Features</h2>
                    <div className="grid grid-cols-2 gap-2 md:grid-cols-3">
                      {room.features.map((feature, index) => (
                        <div key={index} className="flex items-center">
                          <Check className="h-4 w-4 mr-2 text-primary" />
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="amenities">
                  <div className="grid grid-cols-2 gap-4">
                    {room.amenities.map((amenity, index) => (
                      <div key={index} className="flex items-center">
                        <Check className="h-4 w-4 mr-2 text-primary" />
                        <span>{amenity}</span>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="details">
                  <div className="prose max-w-none">
                    <div dangerouslySetInnerHTML={{ __html: room.details || 'No detailed information available.' }} />
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* Booking Section */}
            <div className="lg:col-span-1">
              <Card className="sticky top-24">
                <CardContent className="pt-6">
                  <div className="mb-4">
                    <div className="flex items-baseline justify-between mb-2">
                      <span className="text-2xl font-bold">{formatPrice(room.price)}</span>
                      <span className="text-muted-foreground">/ night</span>
                    </div>
                    <div className="flex items-center">
                      <svg className="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                      <span className="ml-1 text-sm">{room.rating.toFixed(1)} · {room.capacity} guests max</span>
                    </div>
                  </div>

                  <Separator className="my-4" />

                  <div className="space-y-4">
                    <div>
                      <div className="flex flex-col space-y-2">
                        <div className="flex items-center justify-between">
                          <label className="text-sm font-medium">Check-in</label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                className="w-full justify-start text-left font-normal"
                              >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {checkInDate ? (
                                  format(checkInDate, "PP")
                                ) : (
                                  <span>Select date</span>
                                )}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                              <Calendar
                                mode="single"
                                selected={checkInDate}
                                onSelect={handleCheckInSelect}
                                disabled={(date) => date < new Date()}
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                        </div>

                        <div className="flex items-center justify-between">
                          <label className="text-sm font-medium">Check-out</label>
                          <Popover>
                            <PopoverTrigger asChild>
                              <Button
                                variant="outline"
                                className="w-full justify-start text-left font-normal"
                                disabled={!checkInDate}
                              >
                                <CalendarIcon className="mr-2 h-4 w-4" />
                                {checkOutDate ? (
                                  format(checkOutDate, "PP")
                                ) : (
                                  <span>Select date</span>
                                )}
                              </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                              <Calendar
                                mode="single"
                                selected={checkOutDate}
                                onSelect={setCheckOutDate}
                                disabled={(date) => 
                                  !checkInDate || date <= checkInDate || date < addDays(checkInDate, 1)
                                }
                                initialFocus
                              />
                            </PopoverContent>
                          </Popover>
                        </div>

                        <div className="flex items-center justify-between">
                          <label className="text-sm font-medium">Guests</label>
                          <Select
                            value={guests}
                            onValueChange={setGuests}
                          >
                            <SelectTrigger className="w-full">
                              <div className="flex items-center">
                                <Users className="mr-2 h-4 w-4" />
                                <SelectValue placeholder="Select guests" />
                              </div>
                            </SelectTrigger>
                            <SelectContent>
                              {Array.from({ length: room.capacity }, (_, i) => i + 1).map((num) => (
                                <SelectItem key={num} value={num.toString()}>
                                  {num} {num === 1 ? "Guest" : "Guests"}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    {checkInDate && checkOutDate && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>
                            {formatPrice(room.price)} x{" "}
                            {Math.round((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24))} nights
                          </span>
                          <span>
                            {formatPrice(
                              room.price *
                                Math.round((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24))
                            )}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Cleaning fee</span>
                          <span>{formatPrice(50)}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Service fee</span>
                          <span>{formatPrice(30)}</span>
                        </div>
                        <Separator className="my-2" />
                        <div className="flex justify-between font-semibold">
                          <span>Total</span>
                          <span>
                            {formatPrice(
                              room.price *
                                Math.round((checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60 * 24)) +
                                50 +
                                30
                            )}
                          </span>
                        </div>
                      </div>
                    )}

                    <Button 
                      className="w-full" 
                      size="lg"
                      onClick={handleBookNow}
                      disabled={!checkInDate || !checkOutDate}
                    >
                      Book Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default RoomDetail;
