import { useEffect } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { RegisterForm } from "@/components/AuthForms";

const Register = () => {
  // Update page title on component mount
  useEffect(() => {
    document.title = "Register - StayEase";
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow flex items-center justify-center bg-background py-12">
        <div className="w-full max-w-md px-4">
          <RegisterForm />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Register;
